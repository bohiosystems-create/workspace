# Deploy on Vercel

This folder is a static site (no build step). `vercel.json` holds the routes:
/workflows, /compliance, /privacy, /demos, plus /kinan → /demos/kinan/. Pages under /demos/ are sent with a noindex header.

## Option A: dashboard
1. Unzip this file.
2. vercel.com → Add New → Project.
3. Either drag the unzipped folder in, or push it to a Git repo and import it.
4. Framework preset: **Other**. Leave the build command empty and the output directory as the default (`.`).
5. Deploy. Then go to Settings → Domains to attach your domain.

## Option B: CLI
    cd <unzipped folder>
    npx vercel --prod

## What's live
- `/` is the Bohio site.
- `/demos/kinan/` (or `/kinan`) is the Kinan marketing-agent demo. It runs entirely in the browser with demo data and needs no server or keys.

The full Next.js app (kinan-live-app) is not in this zip. On Vercel it needs a hosted database (e.g. Postgres or Turso) in place of SQLite.
