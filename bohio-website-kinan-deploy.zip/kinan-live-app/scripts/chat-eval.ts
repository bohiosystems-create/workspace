// Built-in assistant eval: asks ~90 English and Arabic questions with no AI key and checks each one gets a real
// answer (not the generic fallback) that mentions what it should. Run: npm run chat:eval
import { localAnswer, buildChatContext } from "../lib/chat";

delete process.env.ANTHROPIC_API_KEY;
delete process.env.OPENAI_API_KEY;

// [question, words the answer must contain (any one of each group, "|" separated)]
const CASES: [string, string[]][] = [
  // Today
  ["What's today's brief?", ["Campaign recommendations"]],
  ["What should I change in the campaigns?", ["Campaign recommendations"]],
  ["What changed since yesterday?", ["Daily campaign check"]],
  ["Show me the daily campaign check", ["Daily campaign check", "urgent"]],
  ["What needs my approval?", ["Waiting for your decision"]],
  ["What are the top recommendations?", ["open recommendations"]],
  ["Are we on track against target?", ["Campaign recommendations|target"]],
  ["Help", ["History", "Periods"]],
  ["What can you do?", ["History"]],
  // Definitions
  ["What is cost to sales?", ["Cost to sales"]],
  ["What does CPQL mean?", ["CPQL"]],
  ["What is pacing?", ["Pacing"]],
  ["Define incrementality", ["Incrementality"]],
  ["What is the fair score?", ["Fair score"]],
  ["What is last-touch attribution?", ["Last-touch"]],
  ["What is a benchmark?", ["Benchmark"]],
  // Campaigns
  ["How is ASH-SEARCH-26 doing?", ["Ash Shati", "Benchmark|Today's check"]],
  ["How is Ash Shati Broker Push doing?", ["Broker", "Funnel"]],
  ["Tell me about the Andalus creator programme campaign", ["Andalus", "Funnel"]],
  ["What does today's check say about AND-OFFPLAN-26?", ["Daily campaign check"]],
  // Vendors
  ["Which vendor converts best?", ["Fair scorecard|scorecard"]],
  ["Should we renew Hajar Outdoor?", ["Hajar"]],
  ["What vendor you suggest to terminate and why", ["My recommendation: terminate", "Hajar", "Why"]],
  ["Which agency should we drop?", ["My recommendation", "Hajar"]],
  ["Should we terminate Sada Influence?", ["Sada"]],
  ["أي مورد تقترح إنهاء عقده ولماذا؟", ["توصيتي", "السبب"]],
  ["How is Tasweeq Digital doing?", ["Tasweeq", "scorecard"]],
  ["What do vendors owe us?", ["What vendors owe us|Vendor orchestration"]],
  ["Which trials are running?", ["Trials"]],
  ["Draft an email to Hajar Outdoor", ["draft|nothing to email|Which one"]],
  ["Contracts ending soon", ["contracts by end date"]],
  ["Tell me about Wajha Events", ["Wajha", "Past campaigns"]],
  ["Tell me about Mada Outdoor", ["Mada", "alternative"]],
  ["What did Najm Media do for us?", ["Najm", "Past campaigns"]],
  // Compare
  ["Compare Tasweeq Digital and Hajar Outdoor", ["Comparison", "Tasweeq", "Hajar"]],
  ["Compare Ash Shati and Marina Tower", ["Comparison", "Ash Shati", "Marina"]],
  ["Brokers vs influencers", ["Comparison"]],
  ["Compare 2024 and 2025", ["Year comparison", "2024", "2025"]],
  ["2025 vs 2026", ["Year comparison"]],
  // Periods
  ["How much did we spend in March?", ["2026-03", "spend"]],
  ["Sales in Q1 2025 by project", ["Q1 2025", "By project"]],
  ["Total spend in 2024", ["2024", "spend"]],
  ["How many contracts last month?", ["2026-05", "contracts"]],
  ["Spend in April by channel", ["2026-04", "By channel"]],
  ["How much did Hajar Outdoor spend in February?", ["Hajar", "2026-02"]],
  ["Spend year to date", ["2026 YTD"]],
  // History
  ["What did we learn from past campaigns?", ["What the 2023–2025 campaigns taught us"]],
  ["How did Ramadan campaigns perform?", ["Ramadan", "Campaign history"]],
  ["How did summer campaigns do?", ["Summer"]],
  ["Worst past campaigns", ["Least efficient"]],
  ["Best campaigns last year", ["Most efficient"]],
  ["Past broker campaigns", ["Campaign history", "Broker"]],
  ["Show me the campaign history", ["Campaign history", "Lessons"]],
  ["Benchmarks by channel from history", ["Benchmarks by channel"]],
  ["Tell me about MAR-RAMADAN-25", ["Lesson"]],
  ["Past campaigns for Andalus Quarter", ["Campaign history", "Andalus"]],
  ["Previous radio campaigns", ["Radio"]],
  ["What happened in 2024 campaigns history?", ["Campaign history", "2024"]],
  // Projects and channels
  ["How is Andalus Quarter doing?", ["Andalus Quarter", "History 2023–2025"]],
  ["How is Marina Tower performing?", ["Marina Tower"]],
  ["How are influencers performing?", ["Influencer", "Benchmark"]],
  ["How is outdoor doing?", ["Outdoor|Billboards", "Benchmark"]],
  ["How are the portals doing?", ["Portal"]],
  // Data
  ["Do vendor numbers match the CRM?", ["CRM verification"]],
  ["Which agency runs each Meta campaign?", ["Meta ads"]],
  ["Overdue invoices", ["Supplier invoices"]],
  ["What's the budget plan for June?", ["Budget plan"]],
  ["What data do we read from Kinan's sales agent?", ["Data from Kinan's sales agent", "read-only"]],
  ["Show the daily report schedule", ["Daily report"]],
  ["Incrementality tests", ["Controlled tests"]],
  ["Overall spend and sales", ["Overall"]],

  // Charts from a prompt
  ["Generate a pie chart with revenue generated by vendor", ["Revenue (contracted sales) by vendor", "Mubasher"]],
  ["Line chart of monthly spend for Marina Tower", ["Marketing spend by month — Marina Tower"]],
  ["Bar chart of cost to sales by channel in 2025", ["Cost to sales by channel", "2025"]],
  ["Chart cost to sales by vendor as a pie", ["shown as bars"]],
  ["Graph sales by year", ["by year", "2023"]],
  ["Donut chart of qualified leads by project last month", ["Qualified leads (CRM) by project", "2026-05"]],
  ["Pie chart of leads by buyer type", ["by buyer type", "Investor"]],
  ["Visualise spend by channel", ["Marketing spend by channel"]],
  ["Generate a graph that tracks the meta ads generated revenue over the last six months", ["Meta ads — CRM revenue by month", "2025-12"]],
  ["Meta spend by agency as a pie", ["Meta ads — spend by agency", "Tasweeq"]],
  ["ارسم رسماً بيانياً دائرياً للإيرادات حسب المورد", ["الإيرادات", "حسب المورد"]],
  ["مخطط أعمدة للإنفاق حسب المشروع", ["الإنفاق التسويقي حسب المشروع"]],

  // Campaign ideation
  ["Give me campaign ideas for Marina Tower in Ramadan with SAR 300K", ["Market initiatives", "Marina Tower", "February 2027", "SAR 300K"]],
  ["Brainstorm a new campaign for Andalus", ["Market initiatives", "Andalus Quarter", "Forecast"]],
  ["Any unusual drop in leads or sales?", ["What the data shows today", "Marina Tower", "Andalus Quarter", "contracts down", "featured slot ended"]],
  ["What does the data show today?", ["What the data shows today", "Email", "Invoices", "Competitors", "Initiatives"]],
  ["Anything unusual in the data?", ["What the data shows today", "Lumen Residences"]],
  ["هل هناك انخفاض مفاجئ في العملاء؟", ["ما تُظهره البيانات اليوم", "برج المارينا"]],
  ["Give me market initiatives for Andalus", ["Market initiatives", "Answers the signal", "refill the top of the funnel", "creative refresh"]],
  ["Ideas for a summer campaign for Ash Shati", ["July 2026", "priority list"]],
  ["Plan a campaign for the Cityscape season", ["November 2026", "open-house"]],

  // Lead profiles (sample CRM fields)
  ["Which cities do our leads come from?", ["City", "Jeddah", "Riyadh"]],
  ["Investors or end users — who converts better?", ["Buyer type", "Investor"]],
  ["Buyer types for Marina Tower", ["Buyer type — Marina Tower", "Investor"]],
  ["What nationalities are the leads for Marina Tower?", ["Nationality", "GCC"]],
  ["What budget range do buyers have for Andalus?", ["Budget", "Under SAR 1M"]],
  ["Why do we lose leads?", ["Reason lost", "Not a buyer"]],
  ["Lost reasons for Andalus Quarter", ["Reason lost — Andalus Quarter"]],
  ["Age groups of the leads from influencers", ["Age", "25–34"]],
  ["Unit types for Ash Shati", ["Unit type", "Townhouse"]],
  ["Show me the audience profile", ["Buyer type", "City", "Nationality"]],
  ["Does response time affect conversion?", ["First response"]],
  // Creatives (sample, adds up to campaign totals)
  ["Which creatives work best?", ["Creatives by message", "Payment plan"]],
  ["Which ad format performs best for Ash Shati?", ["Creatives by format", "Video 15s"]],
  ["Arabic or English ads?", ["Creatives by language", "Arabic"]],
  ["Which ads are fatigued?", ["Fatigued"]],
  ["Best ads for ASH-SEARCH-26", ["Creatives by creative", "Payment plan 10/90"]],
  // Market, competitors, calendar (sample)
  ["How is the property market in Jeddah?", ["Property market", "Jeddah South", "Mortgages"]],
  ["Price per sqm around Andalus Quarter", ["Jeddah South", "off-plan"]],
  ["What are competitors doing?", ["Competitors", "Sahil Living"]],
  ["Who competes with Marina Tower?", ["Mirsa Developments"]],
  ["When is Ramadan next year?", ["Celebrations and moments", "Ramadan 2027"]],
  ["Key dates in the marketing calendar", ["Cityscape"]],
  // Expanded history
  ["How did Palm Villas campaigns perform?", ["Campaign history", "Palm Villas"]],
  ["Cityscape results in past years", ["Cityscape"]],
  ["Compare 2023 and 2025", ["Year comparison", "2023", "2025"]],
  ["Spend in 2023", ["2023", "spend"]],

  // Arabic
  ["ما موجز اليوم؟", ["توصيات الحملات"]],
  ["ما الجديد منذ الأمس؟", ["الفحص اليومي"]],
  ["ماذا أغير في الحملات؟", ["توصيات الحملات"]],
  ["ما الذي ينتظر اعتمادي؟", ["بانتظار قراركم"]],
  ["مساعدة", ["التاريخ"]],
  ["ما معنى نسبة التكلفة إلى المبيعات؟", ["نسبة التكلفة إلى المبيعات"]],
  ["ما معنى وتيرة الإنفاق؟", ["وتيرة"]],
  ["كيف أداء ASH-SEARCH-26؟", ["المعيار|فحص اليوم"]],
  ["أي مورد يحقق أفضل تحويل؟", ["التقييم"]],
  ["هل نجدد لهجر؟", ["هجر"]],
  ["قارن 2024 و 2025", ["مقارنة السنوات"]],
  ["الإنفاق في مارس", ["2026-03"]],
  ["المبيعات في Q1 2025 حسب المشروع", ["Q1 2025", "حسب المشروع"]],
  ["ما الدروس من الحملات السابقة؟", ["ما تعلمناه"]],
  ["كيف كان أداء حملات رمضان؟", ["رمضان"]],
  ["أسوأ الحملات السابقة", ["الأقل كفاءة"]],
  ["كيف أداء الأندلس؟", ["الأندلس"]],
  ["كيف أداء المؤثرين؟", ["المعيار"]],
  ["هل أرقام الموردين تطابق نظام إدارة العملاء؟", ["التحقق"]],
  ["من يدير حملات ميتا؟", ["ميتا"]],
  ["الفواتير المتأخرة", ["فواتير الموردين"]],
  ["خطة الميزانية", ["خطة الميزانية"]],
  ["ماذا أرسلنا إلى كنان؟", ["كنان"]],
  ["حدثني عن وجهة للفعاليات", ["حملات سابقة"]],
  ["معيار الوسطاء في الحملات السابقة", ["تاريخ الحملات"]],
  ["اقترح حملة جديدة للأندلس في نوفمبر", ["مبادرات السوق", "نوفمبر 2026"]],
  ["أفكار لحملة رمضان لبرج المارينا", ["مبادرات السوق", "فبراير 2027"]],
  ["من أين يأتي العملاء؟ حسب المدينة", ["المدينة", "جدة"]],
  ["لماذا نخسر العملاء؟", ["سبب الخسارة"]],
  ["أي الإعلانات الأفضل؟", ["الإعلانات حسب"]],
  ["كيف السوق العقاري في جدة؟", ["السوق العقاري"]],
  ["ماذا يفعل المنافسون؟", ["المنافسون"]],
  ["متى رمضان القادم؟", ["المناسبات والمواسم"]],
  ["المستثمرون أم المستخدمون النهائيون؟", ["نوع المشتري"]],

  // Campaign history (no menu page; asked through the assistant)
  ["List the 2024 campaigns", ["Campaign history — 2024", "Palm Villas"]],
  ["Chart cost to sales by season", ["Cost to sales by season", "Ramadan"]],
  ["What does our campaign history teach us?", ["Campaign history", "Lessons"]],

  // Changing the daily report from the chat (run in order; the last one resets it)
  ["Reset the daily report to default", ["Daily report updated|Nothing to change|already"]],
  ["Remove the invoices section from the daily report", ["Daily report updated", "Supplier invoices"]],
  ["Move risks to the top of the report, then add a note to the report: Eid break, no approvals", ["moved", "Risks", "Eid break, no approvals"]],
  ["Only show Andalus Quarter in the report", ["focus on Andalus Quarter"]],
  ["Keep the report to the top 3 items", ["at most 3"]],
  ["Add a pie chart of spend by channel to the report", ["added the chart"]],
  ["Add a note to the report: Ramadan budget freeze starts Sunday", ["Ramadan budget freeze starts Sunday"]],
  ["What's in the daily report?", ["The daily report, in order", "Not shown"]],
  ["Undo the last report change", ["Undone"]],
  ["احذف قسم المخاطر من التقرير", ["تم تعديل التقرير اليومي", "المخاطر"]],
  ["أعلى 5 بنود فقط في التقرير", ["تم تعديل التقرير اليومي", "5"]],
  ["Change the report please", ["I can change the daily report"]],
  ["Reset the daily report to default", ["back to the standard report"]],
  // Changing the Campaigns page's dashboards from the chat (run in order; the last one resets it)
  ["Reset the campaign dashboards", ["Campaign dashboards updated|Nothing to change"]],
  ["Add cost per qualified lead to the campaign dashboards", ["Campaign dashboards updated", "Cost per qualified lead"]],
  ["Remove the funnel from the campaign dashboards", ["removed", "funnel"]],
  ["Add a chart of qualified leads by month to each campaign dashboard", ["Qualified leads by month"]],
  ["Add a chart of leads by city to each campaign", ["Leads by city"]],
  ["Sort campaigns by cost to sales", ["sorted by cost to sales", "lowest first"]],
  ["Show only live campaigns on the campaigns page", ["live campaigns only"]],
  ["Only Andalus Quarter campaigns on the dashboards", ["Andalus Quarter"]],
  ["What's on the campaign dashboards?", ["Campaigns page", "Figures on each campaign"]],
  ["Undo the last campaign dashboard change", ["Undone"]],
  ["أضف وتيرة الإنفاق إلى لوحات الحملات", ["تم تعديل لوحات الحملات", "وتيرة الإنفاق"]],
  ["رتّب الحملات حسب المبيعات", ["مرتبة حسب المبيعات"]],
  ["Reset the campaign dashboards", ["back to the standard campaign dashboards"]],
  // Any page's dashboard from the chat (run in order; the last one resets)
  ["Reset all dashboards", ["Dashboards updated|Nothing to change"]],
  ["Remove the YTD sales from all dashboards", ["Dashboards updated", "Sales year to date"]],
  ["Hide the budget plan on the director page", ["Budget plan"]],
  ["Hide the alerts on the campaigns page", ["Alerts"]],
  ["What is hidden on the dashboards?", ["Hidden on the dashboards", "Budget plan"]],
  ["Undo the last dashboard change", ["Undone"]],
  ["أزل جدول التقييم من صفحة الموردين", ["تم تعديل اللوحات"]],
  ["Reset all dashboards", ["every dashboard back to standard"]],
  // News and celebrations
  ["What's in the news in Jeddah?", ["In the news", "Jeddah"]],
  ["Upcoming celebrations", ["Celebrations and moments", "Ramadan"]],
  // …and questions that mention campaigns stay questions
  ["Show spend for each campaign", ["!Campaign dashboards updated"]],
];

const FALLBACK = /I'm your AI assistant director of marketing\. Ask me|أنا مساعد مدير التسويق الذكي\. اسألوني|couldn't match that question|لم أتمكن من مطابقة/;

(async () => {
  const ctx = { en: await buildChatContext("en"), ar: await buildChatContext("ar") };
  let pass = 0;
  const fails: string[] = [];
  for (const [question, groups] of CASES) {
    const ar = /[؀-ۿ]/.test(question);
    const r = await localAnswer(question, ar ? ctx.ar : ctx.en, undefined, ar ? "ar" : "en");
    const missing = groups.filter((g) => g.startsWith("!") ? r.reply.toLowerCase().includes(g.slice(1).toLowerCase()) : !g.split("|").some((w) => r.reply.toLowerCase().includes(w.toLowerCase())));
    const fb = FALLBACK.test(r.reply);
    if (!fb && !missing.length) pass++;
    else fails.push(`✗ ${question}\n    ${fb ? "fell back to the generic answer" : `missing: ${missing.join(", ")}`}\n    got: ${r.reply.slice(0, 220).replace(/\n/g, " ⏎ ")}`);
    if (process.argv.includes("-v")) console.log(`\n### ${question}\n${r.reply}`);
  }
  if (fails.length) console.log(fails.join("\n"));
  console.log(`\n${pass}/${CASES.length} questions answered with the expected content.`);
  process.exit(fails.length ? 1 : 0);
})();
