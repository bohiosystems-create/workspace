// Guard: a shrinking orbit can briefly compute a negative radius, which canvas rejects with an error. Clamp to 0.
(function () { var P = typeof CanvasRenderingContext2D !== "undefined" && CanvasRenderingContext2D.prototype; if (!P || P.arc.__safe) return; var arc = P.arc; P.arc = function (x, y, r, a0, a1, ccw) { return arc.call(this, x, y, r < 0 ? 0 : r, a0, a1, ccw); }; P.arc.__safe = true; var rg = P.createRadialGradient; P.createRadialGradient = function (x0, y0, r0, x1, y1, r1) { return rg.call(this, x0, y0, r0 < 0 ? 0 : r0, x1, y1, r1 < 0 ? 0 : r1); }; })();
(function () {
  const INK = "0,9,25";
  const PAPER = "230,226,226";
  const PHASES = [
    { label: "Investment",   r: 0.80, speed: 0.40, inc: 0, node: 0, phase: 0.0, size: 4.2 },
    { label: "Construction", r: 1.15, speed: 0.27, inc: 0, node: 0, phase: 1.35, size: 4.6 },
    { label: "Development",  r: 1.50, speed: 0.185, inc: 0, node: 0, phase: 2.7, size: 4.4 },
    { label: "Sales",        r: 1.85, speed: 0.13, inc: 0, node: 0, phase: 4.05, size: 4.0 },
    { label: "Operations",   r: 2.20, speed: 0.095, inc: 0, node: 0, phase: 5.4, size: 4.2 }
  ];

  const rotX = (p, a) => ({ x: p.x, y: p.y * Math.cos(a) - p.z * Math.sin(a), z: p.y * Math.sin(a) + p.z * Math.cos(a) });
  const rotY = (p, a) => ({ x: p.x * Math.cos(a) + p.z * Math.sin(a), y: p.y, z: -p.x * Math.sin(a) + p.z * Math.cos(a) });

  class BohioSolar extends HTMLElement {
    connectedCallback() {
      if (this._built) return;
      this._built = true;
      this.style.cssText = "display:block;width:100%;height:100%";
      this.canvas = document.createElement("canvas");
      this.canvas.style.cssText = "display:block;width:100%;height:100%";
      this.appendChild(this.canvas);
      this.ctx = this.canvas.getContext("2d");
      this.t0 = performance.now();
      this.applyPalette();
      this._ro = new ResizeObserver(() => this.resize());
      this._ro.observe(this);
      this.resize();
      this.loop = this.loop.bind(this);
      this.drawOnce();
      this._vis = () => { if (!document.hidden) { cancelAnimationFrame(this._raf); this._raf = requestAnimationFrame(this.loop); } else this.drawOnce(); };
      document.addEventListener("visibilitychange", this._vis);
      // watchdog: rAF callbacks scheduled while the page is hidden can be dropped
      this._watch = setInterval(() => {
        if (document.hidden) return;
        if (performance.now() - (this._lastFrame || 0) > 400) {
          cancelAnimationFrame(this._raf);
          this._raf = requestAnimationFrame(this.loop);
        }
      }, 500);
      this._raf = requestAnimationFrame(this.loop);
    }
    static get observedAttributes() { return ["invert"]; }
    attributeChangedCallback() { this.applyPalette(); }
    applyPalette() {
      const inv = this.getAttribute("invert") === "true" || this.hasAttribute("inverted");
      this.paper = inv ? INK : PAPER;      // page background
      this.ink = inv ? PAPER : INK;        // primary marks
      this.line = inv ? "176,188,214" : "58,70,96";
      this.sphere = inv
        ? ["246,247,251", "212,219,234", "160,173,200", "104,118,150"]
        : ["120,132,155", "58,70,96", "12,22,44", "0,9,25"];
      this.spec = inv ? "255,255,255" : PAPER;
      this.grid = inv ? INK : PAPER;
    }
    disconnectedCallback() {
      cancelAnimationFrame(this._raf);
      if (this._ro) this._ro.disconnect();
      if (this._vis) document.removeEventListener("visibilitychange", this._vis);
      clearInterval(this._watch);
      this._built = false;
    }
    resize() {
      const r = this.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      this.w = Math.max(320, r.width);
      this.h = Math.max(240, r.height);
      this.canvas.width = Math.round(this.w * dpr);
      this.canvas.height = Math.round(this.h * dpr);
      this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      if (this.loop) this.drawOnce();
    }

    drawOnce() {
      this._noSchedule = true;
      try { this.loop(performance.now()); } catch (e) {}
      this._noSchedule = false;
    }

    // world -> camera -> screen
    project(p) {
      let q = rotY(p, this.yaw);
      q = rotX(q, this.camTilt);
      const d = 4.2;
      const s = 2.6 / Math.max(0.4, d + q.z);
      const sy = this.SY == null ? this.S : this.SY;
      return { x: this.cx + q.x * s * this.S, y: this.cy + q.y * s * sy, s, z: q.z };
    }
    orbitPoint(o, a) {
      const x = Math.cos(a) * o.r, z = Math.sin(a) * o.r;
      return { x, y: this.well(x, z) - (o.size / 4.2) * 0.02, z };
    }

    // space-time curvature: depth of the fabric at a point on the plane
    well(x, z) {

      let y = -0.42 / Math.sqrt(x * x + z * z + 0.075);
      const bodies = this._bodies || [];
      for (const b of bodies) {
        const dx = x - b.x, dz = z - b.z;
        y -= b.m / Math.sqrt(dx * dx + dz * dz + 0.018);
      }
      return -y * 0.60;
    }

    buildCity() {
      const rnd = i => { const x = Math.sin(i * 127.1 + 3.7) * 43758.5453; return x - Math.floor(x); };
      const n = 40;
      this._city = [];
      for (let i = 0; i < n; i++) {
        const a = (i / n) * Math.PI * 2 + (rnd(i) - 0.5) * 0.12;
        const rad = 2.85 + rnd(i + 90) * 1.05;
        const landmark = rnd(i + 300) > 0.78;
        let w = 0.14 + rnd(i + 7) * 0.13;
        let d = 0.13 + rnd(i + 21) * 0.13;
        const tiers = [];
        const setbacks = landmark ? 4 : 2 + Math.round(rnd(i + 51));
        let hh = (landmark ? 0.78 : 0.46) + Math.pow(rnd(i + 44), 1.6) * (landmark ? 1.05 : 0.62);
        for (let k = 0; k < setbacks; k++) {
          tiers.push({ w, d, h: hh });
          w *= 0.70 + rnd(i * 3 + k) * 0.12;
          d *= 0.70 + rnd(i * 5 + k) * 0.12;
          hh *= 0.62 + rnd(i * 7 + k) * 0.16;
        }
        this._city.push({
          x: Math.cos(a) * rad, z: Math.sin(a) * rad,
          rot: a,
          tiers,
          spire: landmark ? 0.40 + rnd(i + 401) * 0.55 : (rnd(i + 402) > 0.6 ? 0.16 : 0),
          start: rnd(i + 200) * 0.70
        });
      }
    }

    box(bx, bz, w, d, y0, y1, rot) {
      const c = Math.cos(rot), sn = Math.sin(rot);
      const ground = this._cityFrame ? this.well(bx, bz) : 0;
      return [[-1, -1], [1, -1], [1, 1], [-1, 1]].map(([sx, sz]) => {
        const lx = (sx * w) / 2, lz = (sz * d) / 2;
        const x = bx + lx * c - lz * sn, z = bz + lx * sn + lz * c;
        return { base: this.project({ x, y: y0 + ground, z }), top: this.project({ x, y: y1 + ground, z }) };
      });
    }

    cityTop(clock) {
      if (!this._city) this.buildCity();
      const CYCLE = 52;
      const pos = (clock % CYCLE) / CYCLE;
      let top = 0;
      for (const b of this._city) {
        const g = Math.max(0, Math.min(1, (pos - b.start) / 0.075));
        const grow = 1 - Math.pow(1 - g, 3);
        const total = b.tiers.reduce((a, t) => a + t.h, 0) + b.spire + 0.13;
        top = Math.max(top, total * grow);
      }
      return top;
    }

    city(clock) {
      const ctx = this.ctx;
      if (!this._city) this.buildCity();
      const CYCLE = 52;
      const pos = (clock % CYCLE) / CYCLE;
      const items = this._city
        .map(b => {
          const g = Math.max(0, Math.min(1, (pos - b.start) / 0.075));
          return { b, grow: 1 - Math.pow(1 - g, 3), c: this.project({ x: b.x, y: this.well(b.x, b.z), z: b.z }) };
        })
        .filter(o => o.grow > 0.002 && o.c.x > -160 && o.c.x < this.w + 160 && o.c.y > -260 && o.c.y < this.h + 160)
        .sort((p, q) => q.c.z - p.c.z);

      let zMin = Infinity, zMax = -Infinity;
      items.forEach(o => { zMin = Math.min(zMin, o.c.z); zMax = Math.max(zMax, o.c.z); });
      const zSpan = Math.max(0.35, zMax - zMin);

      this._cityFrame = true;
      items.forEach(({ b, grow, c }) => {
        const dep = 0.18 + 0.82 * Math.max(0, Math.min(1, (zMax - c.z) / zSpan));
        const wallA = 0.10 + 0.26 * dep;
        const edgeA = 0.16 + 0.34 * dep;
        const gy = this.well(b.x, b.z);
        // px per world unit of height here -> cap the tower so its top stays in frame
        const unit = c.y - this.project({ x: b.x, y: gy - 1, z: b.z }).y;
        const hCap = unit > 1 ? (c.y - 26) / unit : 1e9;
        const raw = b.tiers.reduce((a, t) => a + t.h, 0) + b.spire;
        const hs = Math.max(0.25, Math.min(1, hCap / raw));
        const tiers = b.tiers.map(t => ({ w: t.w, d: t.d, h: t.h * hs }));
        const spire = b.spire * hs;
        const total = raw * hs;
        const built = total * grow;
        let y = 0;

        const drawTier = (t, y0, y1) => {
          const cor = this.box(b.x, b.z, t.w, t.d, y0, y1, b.rot);
          const quads = [[0, 1], [1, 2], [2, 3], [3, 0]]
            .map(([i, j]) => ({ i, j, mid: (cor[i].base.z + cor[j].base.z) / 2 }))
            .sort((p, q) => q.mid - p.mid);
          quads.forEach(({ i, j }, k) => {
            const front = k >= 2;
            ctx.beginPath();
            ctx.moveTo(cor[i].base.x, cor[i].base.y);
            ctx.lineTo(cor[j].base.x, cor[j].base.y);
            ctx.lineTo(cor[j].top.x, cor[j].top.y);
            ctx.lineTo(cor[i].top.x, cor[i].top.y);
            ctx.closePath();
            ctx.fillStyle = `rgba(${this.line},${wallA * (front ? 1 : 0.5)})`;
            ctx.fill();
            ctx.strokeStyle = `rgba(${this.line},${edgeA})`;
            ctx.lineWidth = 0.55;
            ctx.stroke();
            if (!front) return;
            // art-deco pilasters: vertical ribs up the facade
            const ribs = 4;
            for (let m = 1; m < ribs; m++) {
              const f = m / ribs;
              ctx.beginPath();
              ctx.moveTo(cor[i].base.x + (cor[j].base.x - cor[i].base.x) * f, cor[i].base.y + (cor[j].base.y - cor[i].base.y) * f);
              ctx.lineTo(cor[i].top.x + (cor[j].top.x - cor[i].top.x) * f, cor[i].top.y + (cor[j].top.y - cor[i].top.y) * f);
              ctx.strokeStyle = `rgba(${this.line},${edgeA * 0.5})`;
              ctx.lineWidth = 0.4;
              ctx.stroke();
            }
          });
          // cornice slab at the setback
          const roof = this.box(b.x, b.z, t.w * 1.08, t.d * 1.08, y1, y1 - 0.012, b.rot);
          ctx.beginPath();
          roof.forEach((p, k) => (k ? ctx.lineTo(p.top.x, p.top.y) : ctx.moveTo(p.top.x, p.top.y)));
          ctx.closePath();
          ctx.fillStyle = `rgba(${this.line},${wallA * 1.7})`;
          ctx.fill();
          ctx.strokeStyle = `rgba(${this.line},${edgeA * 1.3})`;
          ctx.lineWidth = 0.6;
          ctx.stroke();
        };

        for (const t of tiers) {
          if (y >= built) break;
          const top = Math.min(y + t.h, built);
          drawTier(t, -y, -top);
          y += t.h;
        }
        // scaffolding + tower crane while the tower is going up
        const rigA = Math.min(1, grow * 8) * Math.min(1, (1 - grow) * 7);
        if (rigA > 0.02) {
          const base = tiers[0];
          const sw = base.w * 1.14, sd = base.d * 1.14;
          const lifts = Math.max(2, Math.round(built / 0.075));
          for (let k = 0; k <= lifts; k++) {
            const yy = -(built * k) / lifts;
            const q = this.box(b.x, b.z, sw, sd, yy, yy, b.rot);
            ctx.beginPath();
            q.forEach((p, m) => (m ? ctx.lineTo(p.base.x, p.base.y) : ctx.moveTo(p.base.x, p.base.y)));
            ctx.closePath();
            ctx.strokeStyle = `rgba(${this.line},${0.20 * rigA * (0.5 + dep)})`;
            ctx.lineWidth = 0.4;
            ctx.stroke();
          }
          const posts = this.box(b.x, b.z, sw, sd, 0, -built, b.rot);
          posts.forEach(p => {
            ctx.beginPath();
            ctx.moveTo(p.base.x, p.base.y);
            ctx.lineTo(p.top.x, p.top.y);
            ctx.strokeStyle = `rgba(${this.line},${0.30 * rigA * (0.5 + dep)})`;
            ctx.lineWidth = 0.55;
            ctx.stroke();
          });

          // tower crane: mast beside the tower, slewing jib, hook line
          const mastR = Math.max(base.w, base.d) * 0.85;
          const mx = b.x + Math.cos(b.rot + 0.6) * mastR;
          const mz = b.z + Math.sin(b.rot + 0.6) * mastR;
          const mastTop = -(built + 0.13);
          const gy = this.well(b.x, b.z);
          const cp = (x, y, z) => this.project({ x, y: y + gy, z });
          const mb = cp(mx, 0, mz);
          const mt = cp(mx, mastTop, mz);
          const strokeSeg = (p, q, a, lw) => {
            ctx.beginPath();
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(q.x, q.y);
            ctx.strokeStyle = `rgba(${this.line},${a})`;
            ctx.lineWidth = lw;
            ctx.stroke();
          };
          strokeSeg(mb, mt, 0.5 * rigA, 1.1);
          // mast lattice
          const rungs = 7;
          for (let k = 1; k < rungs; k++) {
            const f = k / rungs;
            const p = cp(mx, mastTop * f, mz);
            const p2 = cp(mx + 0.018, mastTop * (f + 1 / rungs), mz);
            strokeSeg(p, p2, 0.22 * rigA, 0.4);
          }
          const slew = b.rot + clock * 0.5;
          const jibLen = Math.max(base.w, base.d) * 3.1;
          const jibEnd = cp(mx + Math.cos(slew) * jibLen, mastTop, mz + Math.sin(slew) * jibLen);
          const cJib = cp(mx - Math.cos(slew) * jibLen * 0.38, mastTop, mz - Math.sin(slew) * jibLen * 0.38);
          strokeSeg(mt, jibEnd, 0.5 * rigA, 1);
          strokeSeg(mt, cJib, 0.45 * rigA, 1);
          // hook line with load
          const trolley = 0.55 + 0.35 * Math.sin(clock * 0.9 + b.start * 9);
          const hx = mx + Math.cos(slew) * jibLen * trolley;
          const hz = mz + Math.sin(slew) * jibLen * trolley;
          const hTop = cp(hx, mastTop, hz);
          const hookY = mastTop * (0.25 + 0.4 * (0.5 + 0.5 * Math.sin(clock * 0.7 + b.start * 5)));
          const hBot = cp(hx, hookY, hz);
          strokeSeg(hTop, hBot, 0.35 * rigA, 0.5);
          ctx.beginPath();
          ctx.arc(hBot.x, hBot.y, 1.6, 0, Math.PI * 2);
          ctx.fillStyle = `rgba(${this.line},${0.55 * rigA})`;
          ctx.fill();
        }

        // needle spire
        if (spire && built > total - spire) {
          const shown = built - (total - spire);
          const last = tiers[tiers.length - 1];
          const baseY = total - spire - spire * 0;
          const a = this.project({ x: b.x, y: gy - (total - spire), z: b.z });
          const tip = this.project({ x: b.x, y: gy - ((total - spire) + shown), z: b.z });
          const crown = this.box(b.x, b.z, last.w * 0.45, last.d * 0.45, -(total - spire), -((total - spire) + shown * 0.35), b.rot);
          ctx.beginPath();
          crown.forEach((p, k) => (k ? ctx.lineTo(p.top.x, p.top.y) : ctx.moveTo(p.top.x, p.top.y)));
          ctx.closePath();
          ctx.strokeStyle = `rgba(${this.line},${edgeA * 1.2})`;
          ctx.lineWidth = 0.5;
          ctx.stroke();
          ctx.beginPath();
          ctx.moveTo(a.x, a.y);
          ctx.lineTo(tip.x, tip.y);
          ctx.strokeStyle = `rgba(${this.line},${edgeA * 1.6})`;
          ctx.lineWidth = 0.9;
          ctx.stroke();
        }
      });
      this._cityFrame = false;
    }

    fabric(clock) {
      const ctx = this.ctx;
      const EXT = 6.6, N = 46, SEG = 72;
      const line = pts => {
        for (let k = 0; k < pts.length - 1; k++) {
          const a = pts[k], b = pts[k + 1];
          if ((a.x < -60 && b.x < -60) || (a.x > this.w + 60 && b.x > this.w + 60)) continue;
          if ((a.y < -60 && b.y < -60) || (a.y > this.h + 60 && b.y > this.h + 60)) continue;
          const dep = Math.max(0, Math.min(1, (2.6 - a.z) / 4.2));
          ctx.beginPath();
          ctx.moveTo(a.x, a.y);
          ctx.lineTo(b.x, b.y);
          ctx.strokeStyle = `rgba(${this.line},${0.04 + 0.18 * dep})`;
          ctx.lineWidth = 0.5 + 0.35 * dep;
          ctx.stroke();
        }
      };
      for (let i = 0; i <= N; i++) {
        const u = -EXT + (2 * EXT * i) / N;
        const rows = [], cols = [];
        for (let k = 0; k <= SEG; k++) {
          const v = -EXT + (2 * EXT * k) / SEG;
          rows.push(this.project({ x: u, y: this.well(u, v), z: v }));
          cols.push(this.project({ x: v, y: this.well(v, u), z: u }));
        }
        line(rows);
        line(cols);
      }
    }

    text3d(str, x, y, align, fs, dirX, dirY, depth, topA) {
      const ctx = this.ctx;
      ctx.font = `${fs}px "Dallas Light","Dallas",Georgia,serif`;
      if ("letterSpacing" in ctx) ctx.letterSpacing = "0.12em";
      ctx.textAlign = align;
      ctx.textBaseline = "middle";
      const steps = Math.max(3, Math.round(depth));
      for (let k = steps; k >= 1; k--) {
        const f = k / steps;
        ctx.fillStyle = `rgba(${this.line},${0.10 + 0.24 * (1 - f) * topA})`;
        ctx.fillText(str, x + dirX * depth * f, y + dirY * depth * f);
      }
      ctx.fillStyle = `rgba(${this.ink},${topA})`;
      ctx.fillText(str, x, y);
      if ("letterSpacing" in ctx) ctx.letterSpacing = "0px";
    }

    spherePoint(cx, cy, r, spin, axis, lat, lon) {
      const cl = Math.cos(lat);
      let p = { x: cl * Math.cos(lon + spin), y: Math.sin(lat), z: cl * Math.sin(lon + spin) };
      p = rotX(p, -axis);
      return { x: cx + p.x * r, y: cy - p.y * r, z: p.z };
    }

    wrapText(str, cx, cy, r, spin, axis, lonStart, lat, fs, strength) {
      const ctx = this.ctx;
      const chars = str.split("");
      const span = 0.13 * chars.length;
      for (let i = 0; i < chars.length; i++) {
        const lon = lonStart + (i - (chars.length - 1) / 2) * (span / chars.length);
        const p = this.spherePoint(cx, cy, r * 1.015, spin, axis, lat, lon);
        if (p.z > -0.06) continue;
        const face = Math.min(1, -p.z / 0.8);
        const size = fs * (0.62 + 0.38 * face);
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(axis * 0.5 * (p.x - cx) / r);
        ctx.font = `${size}px "Dallas Light","Dallas",Georgia,serif`;
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillStyle = `rgba(${this.grid},${(0.25 + 0.7 * face) * strength})`;
        ctx.fillText(chars[i], 0, 0);
        ctx.restore();
      }
    }

    globe(cx, cy, r, spin, axis, meridians, parallels, strength, lightAng) {
      const ctx = this.ctx;
      if (r < 3) return;
      const gp = (lat, lon) => {
        const cl = Math.cos(lat);
        let p = { x: cl * Math.cos(lon + spin), y: Math.sin(lat), z: cl * Math.sin(lon + spin) };
        p = rotX(p, -axis);
        return { x: cx + p.x * r, y: cy - p.y * r, z: p.z };
      };
      const lit = (px, py) => {
        const ang = Math.atan2(py - cy, px - cx);
        let d = Math.abs(((ang - lightAng + Math.PI * 3) % (Math.PI * 2)) - Math.PI);
        return Math.max(0, 1 - d / Math.PI);
      };
      const arc = pts => {
        for (let k = 0; k < pts.length - 1; k++) {
          const a = pts[k], b = pts[k + 1];
          if (a.z > 0.02 || b.z > 0.02) continue;
          const f = (0.16 + 0.5 * lit(a.x, a.y)) * (1 - Math.abs(a.z) * 0.55) * strength;
          ctx.beginPath();
          ctx.moveTo(a.x, a.y);
          ctx.lineTo(b.x, b.y);
          ctx.strokeStyle = `rgba(${this.grid},${f})`;
          ctx.lineWidth = Math.max(0.35, r * 0.012);
          ctx.stroke();
        }
      };
      for (let m = 0; m < meridians; m++) {
        const lon = (m / meridians) * Math.PI * 2;
        const pts = [];
        for (let k = 0; k <= 72; k++) pts.push(gp(-Math.PI / 2 + (k / 72) * Math.PI, lon));
        arc(pts);
      }
      for (let i = 1; i <= parallels; i++) {
        const lat = (-1 + (2 * i) / (parallels + 1)) * (Math.PI / 2) * 0.8;
        const pts = [];
        for (let k = 0; k <= 120; k++) pts.push(gp(lat, (k / 120) * Math.PI * 2));
        arc(pts);
      }
    }

    loop(now) {
      this._lastFrame = performance.now();
      const ctx = this.ctx;
      const t = (now - this.t0) / 1000;
      const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
      const clock = reduce ? 6 : t * 0.75;
      this.yaw = clock * 0.075;
      this.camTilt = 0.62;
      this.cx = this.w / 2;
      this.cy = this.h / 2;
      // fit from static geometry only (flat orbit circles) so the scale never jitters
      if (this._fitKey !== this.w + "x" + this.h) {
        this.S = 1; this.SY = 1;
        let mx = 0.001, my = 0.001;
        const savedBodies = this._bodies;
        this._bodies = [];
        PHASES.forEach(o => {
          for (let k = 0; k < 72; k++) {
            const a = (k / 72) * Math.PI * 2;
            const x = Math.cos(a) * o.r, z = Math.sin(a) * o.r;
            const q = this.project({ x, y: this.well(x, z) - 0.11, z });
            mx = Math.max(mx, Math.abs(q.x - this.cx));
            my = Math.max(my, Math.abs(q.y - this.cy));
          }
        });
        this._bodies = savedBodies;
        const rMax = 5.4 * (this.w < 720 ? 2.7 : 5.2) * 0.75;
        const padX = Math.min(96, this.w * 0.08) + rMax, padY = 46 + rMax + (this.w < 720 ? 18 : 26);
        this.S = (this.w / 2 - padX) / mx;
        this.SY = Math.min(this.S, (this.h / 2 - padY) / my);
        this._fitKey = this.w + "x" + this.h;
      }

      ctx.clearRect(0, 0, this.w, this.h);
      ctx.fillStyle = `rgb(${this.paper})`;
      ctx.fillRect(0, 0, this.w, this.h);

      const font = '"Dallas Light","Dallas",Georgia,serif';
      const sun = this.project({ x: 0, y: 0, z: 0 });
      const sunIn = Math.min(1, clock / 1.0);
      const alpha = z => {
        const k = (2.2 - z) / 4.0; // nearer -> larger
        return Math.max(0.05, Math.min(1, k));
      };

      // fixed even spread with a bounded rate wobble: always apart, never jitters
      const TAU = Math.PI * 2;
      const angles = PHASES.map((o, i) =>
        clock * 0.19 * Math.PI + (i * TAU) / PHASES.length + Math.sin(clock * 0.22 + i * 1.3) * 0.17
      );

      this._bodies = PHASES.map((o, i) => {
        const a = angles[i];
        return { x: Math.cos(a) * o.r, z: Math.sin(a) * o.r, m: 0.15 * (o.size / 4.2) };
      });

      const planets = PHASES.map((o, i) => {
        const a = angles[i];
        const w = this.orbitPoint(o, a);
        const p = this.project(w);
        const born = Math.min(1, Math.max(0, (clock - 0.4 - i * 0.22) / 1.0));
        return { o, i, p, e: 1 - Math.pow(1 - born, 3), a };
      });

      // orbit paths, depth-faded per segment; far halves first
      const drawOrbit = (o, nearHalf) => {
        const N = 150;
        for (let k = 0; k < N; k++) {
          const p1 = this.project(this.orbitPoint(o, (k / N) * Math.PI * 2));
          const p2 = this.project(this.orbitPoint(o, ((k + 1) / N) * Math.PI * 2));
          const isNear = (p1.z + p2.z) / 2 <= 0;
          if (isNear !== nearHalf) continue;
          ctx.beginPath();
          ctx.moveTo(p1.x, p1.y);
          ctx.lineTo(p2.x, p2.y);
          ctx.strokeStyle = `rgba(${this.line},0.5)`;
          ctx.lineWidth = isNear ? 1.4 : 1.1;
          ctx.stroke();
        }
      };
      this.city(clock);
      this.fabric(clock);

      // neural filaments: sun <-> planet, live signal traffic
      const linkPath = (pl, clock) => {
        const dx = pl.p.x - sun.x, dy = pl.p.y - sun.y;
        const len = Math.hypot(dx, dy) || 1;
        const nx = -dy / len, ny = dx / len;
        const amp = 0;
        const pts = [];
        const N = 30;
        for (let k = 0; k <= N; k++) {
          const t = k / N;
          const env = Math.sin(Math.PI * t);
          const wob =
            Math.sin(t * 5.2 + clock * 1.5 + pl.i * 2.1) * 0.7 +
            Math.sin(t * 11.0 - clock * 2.2 + pl.i) * 0.3;
          const off = amp * env * wob;
          pts.push({
            x: sun.x + dx * t * pl.e + nx * off * pl.e,
            y: sun.y + dy * t * pl.e + ny * off * pl.e,
            t
          });
        }
        return pts;
      };
      const pointAt = (pts, t) => {
        const f = Math.max(0, Math.min(0.999, t)) * (pts.length - 1);
        const i = Math.floor(f), r = f - i;
        const a = pts[i], b = pts[Math.min(pts.length - 1, i + 1)];
        return { x: a.x + (b.x - a.x) * r, y: a.y + (b.y - a.y) * r };
      };
      const drawLink = (pl, nearHalf) => {
        if ((pl.p.z <= 0) !== nearHalf) return;
        if (pl.e <= 0) return;
        const near = pl.p.z <= 0;
        const pts = linkPath(pl, clock);
        // firing envelope: each filament pulses in and out of activity
        const fire = 0.35 + 0.65 * Math.pow(0.5 + 0.5 * Math.sin(clock * 0.9 + pl.i * 1.7), 3);
        const baseA = (near ? 0.32 : 0.14) * (0.45 + 0.55 * fire);

        // sheath
        ctx.beginPath();
        pts.forEach((p, k) => (k ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)));
        ctx.strokeStyle = `rgba(${this.line},${baseA * 0.5})`;
        ctx.lineWidth = near ? 3.2 : 2.2;
        ctx.lineCap = "round";
        ctx.stroke();
        // core strand
        ctx.beginPath();
        pts.forEach((p, k) => (k ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)));
        ctx.strokeStyle = `rgba(${this.grid === undefined ? this.line : this.line},${baseA * 1.5})`;
        ctx.lineWidth = near ? 1.1 : 0.8;
        ctx.stroke();

        // synaptic nodes along the filament
        for (let k = 1; k < 4; k++) {
          const t = k / 4;
          const q = pointAt(pts, t);
          const tw = 0.4 + 0.6 * (0.5 + 0.5 * Math.sin(clock * 2.1 + k * 2 + pl.i));
          ctx.beginPath();
          ctx.arc(q.x, q.y, (near ? 1.5 : 1.1) * (0.6 + 0.7 * tw), 0, Math.PI * 2);
          ctx.fillStyle = `rgba(${this.line},${baseA * (0.7 + 0.8 * tw)})`;
          ctx.fill();
        }

        if (pl.e < 1) return;
        // signal packets travelling both ways, with short trailing streaks
        const packets = 3;
        for (let k = 0; k < packets; k++) {
          const out = k % 2 === 0;
          const speed = 0.30 + 0.08 * k;
          const ph = ((clock * speed + k * 0.37 + pl.i * 0.21) % 1);
          const t = out ? ph : 1 - ph;
          const head = pointAt(pts, t);
          const tailT = out ? Math.max(0, t - 0.10) : Math.min(1, t + 0.10);
          const tail = pointAt(pts, tailT);
          const fade = Math.sin(ph * Math.PI) * (near ? 1 : 0.45) * (0.4 + 0.6 * fire);
          ctx.beginPath();
          ctx.moveTo(tail.x, tail.y);
          ctx.lineTo(head.x, head.y);
          ctx.strokeStyle = `rgba(${this.spec},${0.30 * fade})`;
          ctx.lineWidth = near ? 1.6 : 1.1;
          ctx.stroke();
          ctx.beginPath();
          ctx.arc(head.x, head.y, (out ? 2.6 : 2.0) * pl.p.s * 1.6, 0, Math.PI * 2);
          ctx.fillStyle = `rgba(${this.spec},${0.85 * fade})`;
          ctx.fill();
        }
      };
      planets.forEach(pl => drawLink(pl, false));

      // far planets
      const drawPlanet = pl => {
        if (pl.e <= 0) return;
        const near = pl.p.z <= 0;
        const r = pl.o.size * pl.p.s * (this.w < 720 ? 2.7 : 5.2) * pl.e;

        // lit sphere: light source is the sun at screen centre
        const dx = sun.x - pl.p.x, dy = sun.y - pl.p.y;
        const dl = Math.hypot(dx, dy) || 1;
        const lx = pl.p.x + (dx / dl) * r * 0.52;
        const ly = pl.p.y + (dy / dl) * r * 0.52 - r * 0.12;
        const dim = near ? 1 : 0.5 * alpha(pl.p.z) + 0.25;
        // contact shadow on the orbit plane
        ctx.beginPath();
        ctx.ellipse(pl.p.x, pl.p.y + r * 0.25, r * 1.15, r * 0.4, 0, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(${this.ink},${0.08 * dim})`;
        ctx.fill();
        const sg = ctx.createRadialGradient(lx, ly, r * 0.05, pl.p.x, pl.p.y, r * 1.25);
        sg.addColorStop(0,    `rgba(${this.sphere[0]},${0.95 * dim})`);
        sg.addColorStop(0.30, `rgba(${this.sphere[1]},${0.96 * dim})`);
        sg.addColorStop(0.72, `rgba(${this.sphere[2]},${0.97 * dim})`);
        sg.addColorStop(1,    `rgba(${this.sphere[3]},${0.98 * dim})`);
        ctx.beginPath();
        ctx.arc(pl.p.x, pl.p.y, r, 0, Math.PI * 2);
        ctx.fillStyle = sg;
        ctx.fill();
        const ptg = ctx.createRadialGradient(lx, ly, r * 0.1, pl.p.x, pl.p.y, r * 1.15);
        ptg.addColorStop(0, `rgba(${this.paper},0)`);
        ptg.addColorStop(0.55, `rgba(${this.paper},0.10)`);
        ptg.addColorStop(1, `rgba(${this.paper},0.62)`);
        ctx.save();
        ctx.beginPath();
        ctx.arc(pl.p.x, pl.p.y, r, 0, Math.PI * 2);
        ctx.clip();
        ctx.fillStyle = ptg;
        ctx.fillRect(pl.p.x - r, pl.p.y - r, r * 2, r * 2);
        ctx.restore();
        // rim light on the sunward edge
        ctx.beginPath();
        ctx.arc(pl.p.x, pl.p.y, r * 0.99, Math.atan2(dy, dx) - 1.0, Math.atan2(dy, dx) + 1.0);
        ctx.strokeStyle = `rgba(${this.spec},${0.5 * dim})`;
        ctx.lineWidth = Math.max(0.6, r * 0.10);
        ctx.stroke();
        // specular
        ctx.beginPath();
        ctx.arc(lx, ly, Math.max(0.8, r * 0.16), 0, Math.PI * 2);
        ctx.fillStyle = `rgba(${this.spec},${0.55 * dim})`;
        ctx.fill();
        this.globe(pl.p.x, pl.p.y, r, clock * (0.7 + pl.i * 0.25), 0.36, 8, 3, 0.8 * dim, Math.atan2(dy, dx));
        ctx.beginPath();
        ctx.arc(pl.p.x, pl.p.y, r + 5 * pl.p.s * 1.2, 0, Math.PI * 2);
        ctx.strokeStyle = `rgba(${this.line},${near ? 0.30 : 0.12})`;
        ctx.lineWidth = 1;
        ctx.stroke();

        pl._r = r;
      };
      planets.filter(p => p.p.z > 0).sort((a, b) => b.p.z - a.p.z).forEach(drawPlanet);

      // sun: corona rings + core
      const coreR = (this.w < 720 ? 24 : 38) * sunIn * (this.S / 200 + 0.6);
      for (let k = 0; k < 3; k++) {
        const prog = ((clock * 0.5 + k / 3) % 1);
        ctx.beginPath();
        ctx.arc(sun.x, sun.y, coreR + prog * coreR * 2.6, 0, Math.PI * 2);
        ctx.strokeStyle = `rgba(${this.line},${0.16 * (1 - prog) * sunIn})`;
        ctx.lineWidth = 1;
        ctx.stroke();
      }
      const g = ctx.createRadialGradient(sun.x, sun.y, coreR * 0.4, sun.x, sun.y, coreR * 3.4);
      g.addColorStop(0, `rgba(${this.line},0.18)`);
      g.addColorStop(1, `rgba(${this.line},0)`);
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(sun.x, sun.y, coreR * 3.4, 0, Math.PI * 2);
      ctx.fill();
      const cg = ctx.createRadialGradient(sun.x - coreR * 0.3, sun.y - coreR * 0.35, coreR * 0.1, sun.x, sun.y, coreR * 1.1);
      cg.addColorStop(0, `rgb(${this.sphere[0]})`);
      cg.addColorStop(0.22, `rgb(${this.sphere[1]})`);
      cg.addColorStop(0.52, `rgb(${this.sphere[2]})`);
      cg.addColorStop(0.78, `rgb(${this.sphere[3]})`);
      cg.addColorStop(1, `rgb(${this.sphere[3]})`);
      ctx.beginPath();
      ctx.arc(sun.x, sun.y, coreR, 0, Math.PI * 2);
      ctx.fillStyle = cg;
      ctx.fill();
      this.globe(sun.x, sun.y, coreR, clock * 0.55, 0.42, 20, 11, 1, Math.atan2(-0.4, -0.35));
      // terminator: darken the side away from the viewer-light
      const tg = ctx.createRadialGradient(sun.x - coreR * 0.35, sun.y - coreR * 0.4, coreR * 0.1, sun.x, sun.y, coreR * 1.05);
      tg.addColorStop(0, `rgba(${this.paper},0)`);
      tg.addColorStop(0.6, `rgba(${this.paper},0.30)`);
      tg.addColorStop(1, `rgba(${this.paper},0.78)`);
      ctx.save();
      ctx.beginPath();
      ctx.arc(sun.x, sun.y, coreR, 0, Math.PI * 2);
      ctx.clip();
      ctx.fillStyle = tg;
      ctx.fillRect(sun.x - coreR, sun.y - coreR, coreR * 2, coreR * 2);
      ctx.restore();
      ctx.beginPath();
      ctx.arc(sun.x - coreR * 0.32, sun.y - coreR * 0.36, coreR * 0.16, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(${this.spec},0.6)`;
      ctx.fill();

      this.text3d("BOHIO", sun.x, sun.y - coreR - (this.w < 720 ? 18 : 26), "center", this.w < 720 ? 13 : 17, 0, 0.1, 4, 0.95 * sunIn);

      // near-side links and planets on top
      planets.forEach(pl => drawLink(pl, true));
      planets.filter(p => p.p.z <= 0).sort((a, b) => b.p.z - a.p.z).forEach(drawPlanet);

      // labels last, pushed radially clear of the core so nothing is painted over
      const fs = this.w < 720 ? 11 : 15;
      planets.forEach(pl => {
        if (pl.e <= 0) return;
        const r = pl._r || 6;
        const near = pl.p.z <= 0;
        let lx = pl.p.x, ly = pl.p.y + r + fs * 1.5;
        const dx = lx - sun.x, dy = ly - sun.y;
        const dist = Math.hypot(dx, dy) || 1;
        const clear = coreR + fs * 1.4 + r;
        if (dist < clear) {
          const k = clear / dist;
          lx = sun.x + dx * k;
          ly = sun.y + dy * k;
        }
        this.text3d(pl.o.label.toUpperCase(), lx, ly, "center", fs, 0, 0.09, 3, near ? 0.9 : 0.45);
      });

      if (!this._noSchedule) this._raf = requestAnimationFrame(this.loop);
    }
  }
  if (!customElements.get("bohio-solar")) customElements.define("bohio-solar", BohioSolar);
})();
