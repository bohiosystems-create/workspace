(function () {
  const FG = "#000919";
  const BG = "#e6e2e2";
  const PHASES = [
    { label: "Investment",   r: 0.62, speed: 0.42, inc: 0.10, node: 0.4,  phase: 0.0, size: 4.2 },
    { label: "Construction", r: 0.92, speed: 0.30, inc: -0.16, node: 1.9, phase: 1.7, size: 5.4 },
    { label: "Development",  r: 1.24, speed: 0.22, inc: 0.20, node: 3.2,  phase: 3.4, size: 4.8 },
    { label: "Sales",        r: 1.56, speed: 0.16, inc: -0.09, node: 5.0, phase: 5.1, size: 4.0 }
  ];

  const rotX = (p, a) => ({ x: p.x, y: p.y * Math.cos(a) - p.z * Math.sin(a), z: p.y * Math.sin(a) + p.z * Math.cos(a) });
  const rotY = (p, a) => ({ x: p.x * Math.cos(a) + p.z * Math.sin(a), y: p.y, z: -p.x * Math.sin(a) + p.z * Math.cos(a) });

  class BohioOrbit extends HTMLElement {
    connectedCallback() {
      if (this._built) return;
      this._built = true;
      this.style.cssText = "display:block;width:100%;height:100%";
      this.canvas = document.createElement("canvas");
      this.canvas.style.cssText = "display:block;width:100%;height:100%";
      this.appendChild(this.canvas);
      this.ctx = this.canvas.getContext("2d");
      this.t0 = performance.now();
      this._ro = new ResizeObserver(() => this.resize());
      this._ro.observe(this);
      this.resize();
      this.loop = this.loop.bind(this);
      this._raf = requestAnimationFrame(this.loop);
    }
    disconnectedCallback() {
      cancelAnimationFrame(this._raf);
      if (this._ro) this._ro.disconnect();
      this._built = false;
    }
    resize() {
      const r = this.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      this.w = Math.max(320, r.width);
      this.h = Math.max(240, r.height);
      this.canvas.width = Math.round(this.w * dpr);
      this.canvas.height = Math.round(this.h * dpr);
      this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }

    // world -> camera -> screen
    project(p) {
      let q = rotY(p, this.yaw);
      q = rotX(q, this.camTilt);
      const d = 4.0;
      const s = 2.4 / (d + q.z);
      return { x: this.cx + q.x * s * this.S, y: this.cy + q.y * s * this.S, s, z: q.z };
    }
    orbitPoint(o, a) {
      let p = { x: Math.cos(a) * o.r, y: 0, z: Math.sin(a) * o.r };
      p = rotX(p, o.inc);
      return rotY(p, o.node);
    }

    loop(now) {
      const ctx = this.ctx;
      const t = (now - this.t0) / 1000;
      const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
      const clock = reduce ? 6 : t;
      this.yaw = clock * 0.075;
      this.camTilt = 1.02 + Math.sin(clock * 0.11) * 0.10;
      this.cx = this.w / 2;
      this.cy = this.h / 2;
      this.S = Math.min(this.w * 0.30, this.h * 0.60);

      ctx.clearRect(0, 0, this.w, this.h);
      ctx.fillStyle = BG;
      ctx.fillRect(0, 0, this.w, this.h);

      const font = '"Dallas Light","Dallas",Georgia,serif';
      const sun = this.project({ x: 0, y: 0, z: 0 });
      const sunIn = Math.min(1, clock / 1.0);
      const alpha = z => {
        const k = (2.2 - z) / 4.0; // nearer -> larger
        return Math.max(0.05, Math.min(1, k));
      };

      const planets = PHASES.map((o, i) => {
        const a = o.phase + clock * o.speed * Math.PI;
        const w = this.orbitPoint(o, a);
        const p = this.project(w);
        const born = Math.min(1, Math.max(0, (clock - 0.4 - i * 0.22) / 1.0));
        return { o, i, p, e: 1 - Math.pow(1 - born, 3), a };
      });

      // orbit paths, depth-faded per segment; far halves first
      const drawOrbit = (o, nearHalf) => {
        const N = 150;
        for (let k = 0; k < N; k++) {
          const p1 = this.project(this.orbitPoint(o, (k / N) * Math.PI * 2));
          const p2 = this.project(this.orbitPoint(o, ((k + 1) / N) * Math.PI * 2));
          const isNear = (p1.z + p2.z) / 2 <= 0;
          if (isNear !== nearHalf) continue;
          ctx.beginPath();
          ctx.moveTo(p1.x, p1.y);
          ctx.lineTo(p2.x, p2.y);
          ctx.strokeStyle = `rgba(0,9,25,${(isNear ? 0.30 : 0.11) * alpha(p1.z)})`;
          ctx.lineWidth = isNear ? 1 : 0.7;
          ctx.stroke();
        }
      };
      PHASES.forEach(o => drawOrbit(o, false));

      // spokes + data pulses sun <-> planet (behind-sun ones first)
      const drawLink = (pl, nearHalf) => {
        if ((pl.p.z <= 0) !== nearHalf) return;
        const near = pl.p.z <= 0;
        ctx.beginPath();
        ctx.moveTo(sun.x, sun.y);
        ctx.lineTo(sun.x + (pl.p.x - sun.x) * pl.e, sun.y + (pl.p.y - sun.y) * pl.e);
        ctx.strokeStyle = `rgba(0,9,25,${(near ? 0.26 : 0.10) * alpha(pl.p.z)})`;
        ctx.lineWidth = near ? 1 : 0.7;
        ctx.stroke();
        if (pl.e < 1) return;
        const period = 2.4;
        const ph = ((clock + pl.i * (period / PHASES.length)) % period) / period;
        const out = ph < 0.5;
        const p = out ? ph / 0.5 : (ph - 0.5) / 0.5;
        const from = out ? sun : pl.p, to = out ? pl.p : sun;
        const fade = Math.sin(p * Math.PI) * (near ? 1 : 0.4);
        ctx.beginPath();
        ctx.arc(from.x + (to.x - from.x) * p, from.y + (to.y - from.y) * p, 2.4 * pl.p.s * 1.5, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(0,9,25,${(out ? 0.8 : 0.5) * fade})`;
        ctx.fill();
      };
      planets.forEach(pl => drawLink(pl, false));

      // far planets
      const drawPlanet = pl => {
        if (pl.e <= 0) return;
        const near = pl.p.z <= 0;
        const r = pl.o.size * pl.p.s * 1.5 * pl.e;
        // trailing arc
        const TR = 22;
        ctx.beginPath();
        for (let k = 0; k <= TR; k++) {
          const q = this.project(this.orbitPoint(pl.o, pl.a - (k / TR) * 0.55));
          k ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y);
        }
        ctx.strokeStyle = `rgba(0,9,25,${(near ? 0.55 : 0.2) * alpha(pl.p.z)})`;
        ctx.lineWidth = 1.8;
        ctx.stroke();

        ctx.beginPath();
        ctx.arc(pl.p.x, pl.p.y, r, 0, Math.PI * 2);
        ctx.fillStyle = near ? FG : `rgba(0,9,25,${0.42 * alpha(pl.p.z) + 0.18})`;
        ctx.fill();
        ctx.beginPath();
        ctx.arc(pl.p.x, pl.p.y, r + 5 * pl.p.s * 1.2, 0, Math.PI * 2);
        ctx.strokeStyle = `rgba(0,9,25,${near ? 0.24 : 0.10})`;
        ctx.lineWidth = 1;
        ctx.stroke();

        const fs = Math.max(11, Math.min(18, 12.5 * pl.p.s * 1.6));
        ctx.font = `${fs}px ${font}`;
        if ("letterSpacing" in ctx) ctx.letterSpacing = "0.12em";
        ctx.textBaseline = "middle";
        const outward = pl.p.x >= sun.x ? 1 : -1;
        ctx.textAlign = outward > 0 ? "left" : "right";
        ctx.fillStyle = `rgba(0,9,25,${near ? 0.92 : 0.40})`;
        ctx.fillText(pl.o.label.toUpperCase(), pl.p.x + outward * (r + 13), pl.p.y - r - 7);
        if ("letterSpacing" in ctx) ctx.letterSpacing = "0px";
      };
      planets.filter(p => p.p.z > 0).sort((a, b) => b.p.z - a.p.z).forEach(drawPlanet);

      // sun: corona rings + core
      const coreR = (12 + Math.sin(clock * 1.5) * 1.4) * sunIn * (this.S / 220 + 0.55);
      for (let k = 0; k < 3; k++) {
        const prog = ((clock * 0.5 + k / 3) % 1);
        ctx.beginPath();
        ctx.arc(sun.x, sun.y, coreR + prog * coreR * 2.6, 0, Math.PI * 2);
        ctx.strokeStyle = `rgba(0,9,25,${0.16 * (1 - prog) * sunIn})`;
        ctx.lineWidth = 1;
        ctx.stroke();
      }
      const g = ctx.createRadialGradient(sun.x, sun.y, coreR * 0.4, sun.x, sun.y, coreR * 3.4);
      g.addColorStop(0, "rgba(0,9,25,0.22)");
      g.addColorStop(1, "rgba(0,9,25,0)");
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(sun.x, sun.y, coreR * 3.4, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.arc(sun.x, sun.y, coreR, 0, Math.PI * 2);
      ctx.fillStyle = FG;
      ctx.fill();

      ctx.font = `${Math.max(11, Math.min(15, this.S * 0.055))}px ${font}`;
      if ("letterSpacing" in ctx) ctx.letterSpacing = "0.2em";
      ctx.textAlign = "center";
      ctx.textBaseline = "top";
      ctx.fillStyle = `rgba(0,9,25,${0.9 * sunIn})`;
      ctx.fillText("BOHIO AI", sun.x, sun.y + coreR + 16);
      if ("letterSpacing" in ctx) ctx.letterSpacing = "0px";

      // near halves on top
      PHASES.forEach(o => drawOrbit(o, true));
      planets.forEach(pl => drawLink(pl, true));
      planets.filter(p => p.p.z <= 0).sort((a, b) => b.p.z - a.p.z).forEach(drawPlanet);

      this._raf = requestAnimationFrame(this.loop);
    }
  }
  if (!customElements.get("bohio-orbit")) customElements.define("bohio-orbit", BohioOrbit);
})();
