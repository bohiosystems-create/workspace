(function () {
  const C = "176,188,214";
  const S = "236,240,250";

  class BohioMachines extends HTMLElement {
    connectedCallback() {
      if (this._built) return;
      this._built = true;
      this.style.cssText = "display:block;position:absolute;top:-180px;left:0;right:-40px;bottom:-70px;pointer-events:none";
      this.canvas = document.createElement("canvas");
      this.canvas.style.cssText = "display:block;width:100%;height:100%";
      this.appendChild(this.canvas);
      this.ctx = this.canvas.getContext("2d");
      this.t0 = performance.now();
      this._ro = new ResizeObserver(() => this.resize());
      this._ro.observe(this);
      this.resize();
      this.loop = this.loop.bind(this);
      this.restart = () => { this.t0 = performance.now(); };
      const h1 = this.wordmark();
      if (h1) {
        h1.addEventListener("click", this.restart);
        this._io = new IntersectionObserver(es => {
          es.forEach(e => { if (e.isIntersecting && (performance.now() - this.t0) / 1000 > 16) this.restart(); });
        }, { threshold: 0.4 });
        this._io.observe(h1);
      }
      this._raf = requestAnimationFrame(this.loop);
    }
    disconnectedCallback() {
      cancelAnimationFrame(this._raf);
      if (this._ro) this._ro.disconnect();
      if (this._io) this._io.disconnect();
      this._built = false;
    }
    resize() {
      const r = this.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      this.w = Math.max(120, r.width);
      this.h = Math.max(120, r.height);
      this.canvas.width = Math.round(this.w * dpr);
      this.canvas.height = Math.round(this.h * dpr);
      this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }
    wordmark() {
      let n = this.parentElement;
      while (n && n !== document.body) {
        const h = n.querySelector && n.querySelector("h1");
        if (h) return h;
        n = n.parentElement;
      }
      return document.querySelector("h1");
    }
    portal() {
      const h1 = this.wordmark();
      if (!h1) return null;
      const line = h1.children[0];
      if (!line || line.children.length < 5) return null;
      const el = line.children[4];
      const b = this.canvas.getBoundingClientRect();
      const r = el.getBoundingClientRect();
      if (r.width < 1) return null;
      return { x: r.left - b.left, y: r.top - b.top, w: r.width, h: r.height };
    }

    ln(a, b, al, lw) {
      const c = this.ctx;
      c.beginPath(); c.moveTo(a[0], a[1]); c.lineTo(b[0], b[1]);
      c.strokeStyle = `rgba(${C},${al})`; c.lineWidth = lw; c.stroke();
    }
    rc(x, y, w, h, al, lw) {
      const c = this.ctx;
      c.beginPath(); c.rect(x, y, w, h);
      c.strokeStyle = `rgba(${C},${al})`; c.lineWidth = lw; c.stroke();
    }
    wh(x, y, r, al, spin) {
      const c = this.ctx;
      c.beginPath(); c.arc(x, y, r, 0, Math.PI * 2);
      c.strokeStyle = `rgba(${C},${al})`; c.lineWidth = 1; c.stroke();
      this.ln([x, y], [x + Math.cos(spin) * r * 0.8, y + Math.sin(spin) * r * 0.8], al * 0.7, 0.8);
    }

    truck(x, g, s, al, spin) {
      const bw = 40 * s, bh = 15 * s, cab = 15 * s, y = g - bh - 4 * s;
      this.rc(x, y, bw, bh, al, 1);
      this.rc(x + bw, y + 3 * s, cab, bh - 3 * s, al, 1);
      this.rc(x + 5 * s, y - 10 * s, 20 * s, 10 * s, al * 0.75, 1);
      [x + 8 * s, x + bw - 6 * s, x + bw + cab - 5 * s].forEach(wx => this.wh(wx, g - 4 * s, 4 * s, al, spin));
    }
    digger(x, g, s, al, t) {
      const bw = 32 * s, bh = 13 * s, y = g - bh - 6 * s;
      this.rc(x, y, bw, bh, al, 1);
      this.rc(x - 3 * s, g - 6 * s, bw + 6 * s, 6 * s, al, 1);
      for (let k = 0; k < 4; k++) this.ln([x + (k / 3) * bw, g - 6 * s], [x + (k / 3) * bw, g], al * 0.5, 0.7);
      const px = x + bw - 3 * s, py = y + 3 * s;
      const sw = Math.sin(t * 1.6) * 0.34;
      const b1 = [px + Math.cos(-1.0 + sw) * 28 * s, py + Math.sin(-1.0 + sw) * 28 * s];
      const b2 = [b1[0] + Math.cos(0.5 - sw * 1.4) * 24 * s, b1[1] + Math.sin(0.5 - sw * 1.4) * 24 * s];
      this.ln([px, py], b1, al, 1.3);
      this.ln(b1, b2, al, 1.1);
      const c = this.ctx, bk = 7 * s;
      c.beginPath(); c.moveTo(b2[0], b2[1]); c.lineTo(b2[0] + bk, b2[1] + bk * 0.5); c.lineTo(b2[0] + bk * 0.4, b2[1] + bk * 1.3); c.closePath();
      c.strokeStyle = `rgba(${C},${al})`; c.lineWidth = 1; c.stroke();
    }
    mixer(x, g, s, al, spin) {
      const bh = 13 * s, y = g - bh - 4 * s;
      this.rc(x, y + 2 * s, 14 * s, bh - 2 * s, al, 1);
      const c = this.ctx;
      c.save(); c.translate(x + 30 * s, y - 3 * s); c.rotate(-0.25);
      c.beginPath(); c.ellipse(0, 0, 15 * s, 9 * s, 0, 0, Math.PI * 2);
      c.strokeStyle = `rgba(${C},${al})`; c.lineWidth = 1; c.stroke();
      for (let k = -2; k <= 2; k++) {
        const a = spin * 0.7 + k * 0.7;
        c.beginPath(); c.moveTo(Math.cos(a) * 14 * s, Math.sin(a) * 8 * s);
        c.lineTo(Math.cos(a + 1.2) * 14 * s, Math.sin(a + 1.2) * 8 * s);
        c.strokeStyle = `rgba(${C},${al * 0.45})`; c.lineWidth = 0.7; c.stroke();
      }
      c.restore();
      [x + 5 * s, x + 22 * s, x + 34 * s].forEach(wx => this.wh(wx, g - 4 * s, 4 * s, al, spin));
    }

    loop(now) {
      const ctx = this.ctx;
      const t = (now - this.t0) / 1000;
      ctx.clearRect(0, 0, this.w, this.h);
      const P = this.portal();
      if (!P) { this._raf = requestAnimationFrame(this.loop); return; }

      const s = Math.max(0.7, Math.min(1.6, P.h / 110));
      const px = P.x + P.w / 2, py = P.y + P.h * 0.52;
      const ground = P.y + P.h * 0.92;
      const T0 = 1.75;                       // the O has finished turning
      const site = px + P.w * 1.5 + 70 * s;  // build site, right of the O
      const towerW = Math.max(74, P.w * 1.25);
      const towerH = Math.min(ground - 12, P.h * 2.15);

      if (t < T0) { this._raf = requestAnimationFrame(this.loop); return; }
      const lt = t - T0;

      // portal mouth + ground line
      const glow = Math.max(0, 1 - lt / 7);
      ctx.beginPath();
      ctx.ellipse(px, py, P.w * 0.30, P.h * 0.34, 0, 0, Math.PI * 2);
      ctx.strokeStyle = `rgba(${S},${0.25 * glow})`;
      ctx.lineWidth = 1.2;
      ctx.stroke();
      this.ln([px, ground], [Math.min(this.w, site + towerW + 120 * s), ground], 0.3, 1);

      // machines drive out of the O and take up positions on site
      const fleet = [
        { k: "digger", t0: 0.0, park: site - 46 * s },
        { k: "truck", t0: 0.55, park: site + towerW + 16 * s },
        { k: "mixer", t0: 1.15, park: site + towerW + 76 * s },
        { k: "truck", t0: 1.75, park: site - 118 * s }
      ];
      fleet.forEach((f, i) => {
        const a = lt - f.t0;
        if (a < 0) return;
        const drive = Math.min(1, a / 1.5);
        const e = 1 - Math.pow(1 - drive, 3);
        const x = px - 18 * s + (f.park - (px - 18 * s)) * e;
        const emerge = Math.min(1, a / 0.5);
        const sc = s * (0.35 + 0.65 * emerge);
        const al = 0.5 * emerge;
        const spin = a * 7;
        if (f.k === "digger") this.digger(x, ground, sc, al, lt + i);
        else if (f.k === "truck") this.truck(x, ground, sc, al, drive < 1 ? spin : 0);
        else this.mixer(x, ground, sc, al, drive < 1 ? spin : lt * 2);
      });

      // skyscraper: floors stack, art-deco setbacks
      const FL = 16, FLT = 0.36, START = 2.6;
      const built = Math.max(0, Math.min(FL, (lt - START) / FLT));
      const fh = towerH / FL;
      const widthAt = k => towerW * (k > 12 ? 0.46 : k > 8 ? 0.66 : k > 4 ? 0.85 : 1);
      for (let k = 0; k < Math.ceil(built); k++) {
        const grow = Math.min(1, built - k);
        const wk = widthAt(k);
        const x0 = site + (towerW - wk) / 2;
        const y1 = ground - k * fh;
        const y0 = y1 - fh * grow;
        this.rc(x0, y0, wk, y1 - y0, 0.34, 1);
        // mullions
        const bays = Math.max(3, Math.round(wk / (14 * s)));
        for (let m = 1; m < bays; m++) {
          const mx = x0 + (wk * m) / bays;
          this.ln([mx, y0], [mx, y1], 0.14, 0.6);
        }
        // cornice at a setback
        if (widthAt(k + 1) < wk) this.rc(x0 - 3 * s, y0 - 2 * s, wk + 6 * s, 3 * s, 0.4, 1);
      }
      if (built > 0 && built < FL) {
        // climbing crane beside the tower
        const topY = ground - built * fh;
        const mx = site - 26 * s;
        const mastTop = topY - 46 * s;
        this.ln([mx, ground], [mx, mastTop], 0.45, 1.2);
        for (let y = ground; y > mastTop; y -= 16 * s) {
          this.ln([mx - 4 * s, y], [mx + 4 * s, y - 8 * s], 0.2, 0.6);
          this.ln([mx + 4 * s, y], [mx - 4 * s, y - 8 * s], 0.2, 0.6);
        }
        this.ln([mx - 4 * s, mastTop], [mx + 4 * s, mastTop], 0.4, 0.9);
        const jib = towerW * 1.35;
        this.ln([mx - jib * 0.3, mastTop], [mx + jib, mastTop], 0.45, 1);
        const tr = 0.35 + 0.5 * (0.5 + 0.5 * Math.sin(lt * 1.2));
        const hx = mx + jib * tr;
        const hy = mastTop + (topY - mastTop) * (0.35 + 0.55 * (0.5 + 0.5 * Math.sin(lt * 1.6)));
        this.ln([hx, mastTop], [hx, hy], 0.3, 0.6);
        this.rc(hx - 9 * s, hy, 18 * s, 4 * s, 0.5, 1);
        // scaffold lifts on the top floors
        const wk = widthAt(Math.floor(built));
        const x0 = site + (towerW - wk) / 2;
        this.rc(x0 - 5 * s, topY - 4 * s, wk + 10 * s, Math.min(3 * fh, built * fh), 0.14, 0.7);
      }
      // spire once topped out
      if (built >= FL) {
        const done = Math.min(1, (lt - START - FL * FLT) / 1.2);
        const topY = ground - towerH;
        this.ln([site + towerW / 2, topY], [site + towerW / 2, topY - 46 * s * done], 0.45, 1.4);
        this.rc(site + towerW * 0.34, topY - 8 * s, towerW * 0.32, 8 * s, 0.4 * done, 1);
      }

      this._raf = requestAnimationFrame(this.loop);
    }
  }
  if (!customElements.get("bohio-machines")) customElements.define("bohio-machines", BohioMachines);
})();
