(function () {
  const C = "176,188,214";

  class BohioBuild extends HTMLElement {
    connectedCallback() {
      if (this._built) return;
      this._built = true;
      this.style.cssText = "display:block;position:absolute;top:-104px;left:-28px;right:-28px;bottom:-58px;pointer-events:none";
      this.canvas = document.createElement("canvas");
      this.canvas.style.cssText = "display:block;width:100%;height:100%";
      this.appendChild(this.canvas);
      this.ctx = this.canvas.getContext("2d");
      this.t0 = performance.now();
      this._ro = new ResizeObserver(() => this.resize());
      this._ro.observe(this);
      this.resize();
      this.loop = this.loop.bind(this);
      this.watchReplay();
      this.restart = () => { this.t0 = performance.now(); cancelAnimationFrame(this._raf); this._raf = requestAnimationFrame(this.loop); };
      const h1 = this.wordmark();
      if (h1) {
        h1.style.cursor = "pointer";
        this._click = () => this.restart();
        h1.addEventListener("click", this._click);
        this._io = new IntersectionObserver(es => {
          es.forEach(e => { if (e.isIntersecting && (performance.now() - this.t0) / 1000 > 5) this.restart(); });
        }, { threshold: 0.5 });
        this._io.observe(h1);
      }
      this._raf = requestAnimationFrame(this.loop);
    }
    disconnectedCallback() {
      cancelAnimationFrame(this._raf);
      if (this._ro) this._ro.disconnect();
      if (this._mo) this._mo.disconnect();
      if (this._io) this._io.disconnect();
      this._built = false;
    }
    watchReplay() {
      const h1 = this.wordmark();
      const host = h1 && h1.parentElement;
      if (!host) return;
      this._mo = new MutationObserver(() => {
        this.t0 = performance.now();
        cancelAnimationFrame(this._raf);
        this._raf = requestAnimationFrame(this.loop);
      });
      this._mo.observe(host, { childList: true });
    }
    resize() {
      const r = this.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      this.w = Math.max(120, r.width);
      this.h = Math.max(120, r.height);
      this.canvas.width = Math.round(this.w * dpr);
      this.canvas.height = Math.round(this.h * dpr);
      this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }

    wordmark() {
      let n = this.parentElement;
      while (n && n !== document.body) {
        const h = n.querySelector && n.querySelector("h1");
        if (h) return h;
        n = n.parentElement;
      }
      return document.querySelector("h1");
    }

    letters() {
      const h1 = this.wordmark();
      if (!h1) return [];
      const box = this.canvas.getBoundingClientRect();
      const out = [];
      h1.querySelectorAll("span > span").forEach(el => {
        const r = el.getBoundingClientRect();
        if (r.width < 0.5) return;
        out.push({
          x: r.left - box.left,
          y: r.top - box.top,
          w: r.width,
          h: r.height,
          char: el.textContent
        });
      });
      return out;
    }

    line(a, b, alpha, lw) {
      const ctx = this.ctx;
      ctx.beginPath();
      ctx.moveTo(a[0], a[1]);
      ctx.lineTo(b[0], b[1]);
      ctx.strokeStyle = `rgba(${C},${alpha})`;
      ctx.lineWidth = lw;
      ctx.stroke();
    }
    rect(x, y, w, h, alpha, lw) {
      const ctx = this.ctx;
      ctx.beginPath();
      ctx.rect(x, y, w, h);
      ctx.strokeStyle = `rgba(${C},${alpha})`;
      ctx.lineWidth = lw;
      ctx.stroke();
    }
    wheel(x, y, r, alpha) {
      const ctx = this.ctx;
      ctx.beginPath();
      ctx.arc(x, y, r, 0, Math.PI * 2);
      ctx.strokeStyle = `rgba(${C},${alpha})`;
      ctx.lineWidth = 1;
      ctx.stroke();
    }

    truck(x, ground, s, alpha, spin) {
      const bw = 46 * s, bh = 17 * s, cab = 18 * s;
      const y = ground - bh - 5 * s;
      this.rect(x, y, bw, bh, alpha, 1);
      this.rect(x + bw, y + 3 * s, cab, bh - 3 * s, alpha, 1);
      this.line([x + bw + cab, y + 7 * s], [x + bw + cab + 4 * s, y + 7 * s], alpha, 1);
      // load on the bed
      this.rect(x + 6 * s, y - 11 * s, 22 * s, 11 * s, alpha * 0.8, 1);
      const wy = ground - 5 * s;
      [x + 9 * s, x + bw - 7 * s, x + bw + cab - 6 * s].forEach(wx => {
        this.wheel(wx, wy, 5 * s, alpha);
        const a = spin;
        this.line([wx, wy], [wx + Math.cos(a) * 4 * s, wy + Math.sin(a) * 4 * s], alpha * 0.7, 0.8);
      });
      this.line([x - 8 * s, ground], [x + bw + cab + 10 * s, ground], alpha * 0.35, 0.8);
    }

    digger(x, ground, s, alpha, t) {
      const bodyW = 40 * s, bodyH = 16 * s;
      const y = ground - bodyH - 6 * s;
      this.rect(x, y, bodyW, bodyH, alpha, 1);
      // tracks
      this.rect(x - 3 * s, ground - 7 * s, bodyW + 6 * s, 7 * s, alpha, 1);
      for (let k = 0; k < 5; k++) {
        const tx = x + (k / 4) * bodyW;
        this.line([tx, ground - 7 * s], [tx, ground], alpha * 0.5, 0.7);
      }
      // boom + stick + bucket
      const px = x + bodyW - 4 * s, py = y + 4 * s;
      const swing = Math.sin(t * 1.5) * 0.32;
      const b1 = [px + Math.cos(-1.05 + swing) * 34 * s, py + Math.sin(-1.05 + swing) * 34 * s];
      const b2 = [b1[0] + Math.cos(0.45 - swing * 1.4) * 30 * s, b1[1] + Math.sin(0.45 - swing * 1.4) * 30 * s];
      this.line([px, py], b1, alpha, 1.4);
      this.line(b1, b2, alpha, 1.2);
      const bk = 8 * s;
      const ctx = this.ctx;
      ctx.beginPath();
      ctx.moveTo(b2[0], b2[1]);
      ctx.lineTo(b2[0] + bk, b2[1] + bk * 0.5);
      ctx.lineTo(b2[0] + bk * 0.4, b2[1] + bk * 1.3);
      ctx.closePath();
      ctx.strokeStyle = `rgba(${C},${alpha})`;
      ctx.lineWidth = 1;
      ctx.stroke();
    }

    loop(now) {
      const ctx = this.ctx;
      const t = (now - this.t0) / 1000;
      const END = 4.2;
      ctx.clearRect(0, 0, this.w, this.h);
      if (t > END) {
        this._raf = requestAnimationFrame(this.loop);
        return;
      }
      const out = t > 2.7 ? Math.max(0, 1 - (t - 2.7) / 1.3) : 1;
      const ls = this.letters();
      if (!ls.length) {
        this._raf = requestAnimationFrame(this.loop);
        return;
      }
      const s = Math.max(0.75, Math.min(1.5, this.w / 900));
      const railY = Math.max(14, ls[0].y - 78 * s);
      const ground = Math.min(this.h - 6, ls[ls.length - 1].y + ls[ls.length - 1].h + 34 * s);

      // gantry rail with lattice
      const railIn = Math.min(1, t / 0.45) * out;
      if (railIn > 0.01) {
        const x1 = 0, x2 = this.w * railIn;
        this.line([x1, railY], [x2, railY], 0.5 * out, 1.4);
        this.line([x1, railY + 9 * s], [x2, railY + 9 * s], 0.3 * out, 0.8);
        for (let x = 0; x < x2; x += 26 * s) {
          this.line([x, railY], [x + 13 * s, railY + 9 * s], 0.22 * out, 0.7);
          this.line([x + 26 * s, railY], [x + 13 * s, railY + 9 * s], 0.22 * out, 0.7);
        }
      }
      // ground line
      this.line([0, ground], [this.w * Math.min(1, t / 0.6), ground], 0.35 * out, 1);

      ls.forEach((L, i) => {
        const delay = 0.12 + i * 0.085;
        const local = t - delay;
        if (local < -0.35) return;
        const placing = local < 1.05;
        const cx = L.x + L.w / 2;
        const topY = L.y;
        const hookY = placing ? topY - 12 * s : railY + 9 * s + (topY - 12 * s - railY) * Math.max(0, 1 - (local - 1.05) / 0.55);
        const a = out * (placing ? 1 : Math.max(0, 1 - (local - 1.05) / 0.55));
        if (a <= 0.01) return;

        // trolley on the rail
        this.rect(cx - 7 * s, railY + 2 * s, 14 * s, 8 * s, 0.5 * a, 1);
        // hoist cable
        this.line([cx, railY + 10 * s], [cx, hookY], 0.45 * a, 0.9);
        // hook block
        this.rect(cx - 4 * s, hookY, 8 * s, 5 * s, 0.6 * a, 1);
        if (placing) {
          // slings to the letter's top corners
          this.line([cx, hookY + 5 * s], [L.x + 2, topY], 0.4 * a, 0.8);
          this.line([cx, hookY + 5 * s], [L.x + L.w - 2, topY], 0.4 * a, 0.8);
          // scaffold cage around the letter being set
          const px = 5 * s;
          this.rect(L.x - px, L.y - px, L.w + px * 2, L.h + px * 2, 0.22 * a, 0.8);
          const lifts = 3;
          for (let k = 1; k < lifts; k++) {
            const yy = L.y - px + ((L.h + px * 2) * k) / lifts;
            this.line([L.x - px, yy], [L.x + L.w + px, yy], 0.16 * a, 0.6);
          }
        }
      });

      // vehicles on the ground
      const tr1 = ((t * 0.32) % 1.25) - 0.18;
      this.truck(tr1 * this.w, ground, s, 0.42 * out, t * 3.2);
      const tr2 = ((t * 0.24 + 0.55) % 1.35) - 0.25;
      this.truck(tr2 * this.w, ground, s * 0.82, 0.28 * out, t * 2.6);
      this.digger(this.w * 0.72, ground, s, 0.42 * out, t);
      this.digger(this.w * 0.06, ground, s * 0.8, 0.3 * out, t + 1.4);

      this._raf = requestAnimationFrame(this.loop);
    }
  }
  if (!customElements.get("bohio-build")) customElements.define("bohio-build", BohioBuild);
})();
