# Windows: right-click → "Run with PowerShell", or:  powershell -ExecutionPolicy Bypass -File tools\set-domain.ps1 yourdomain.com
param([Parameter(Mandatory=$true)][string]$Domain)
$Domain = $Domain -replace '^https?://', '' -replace '/$', ''
Get-ChildItem -Path (Join-Path $PSScriptRoot "..\bohio-website") -Filter *.html -Recurse | Where-Object { $_.FullName -notmatch '\\demos\\' } | ForEach-Object {
  $t = Get-Content -Raw -Encoding UTF8 $_.FullName
  if ($t -match 'YOURDOMAIN\.com') { ($t -replace 'YOURDOMAIN\.com', $Domain) | Set-Content -Encoding UTF8 -NoNewline $_.FullName; Write-Host "updated $($_.Name)" }
}
Write-Host "Done: links now point to https://$Domain"
