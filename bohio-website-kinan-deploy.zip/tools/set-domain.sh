#!/bin/sh
# macOS / Linux:  sh tools/set-domain.sh yourdomain.com
[ -z "$1" ] && { echo "usage: sh tools/set-domain.sh yourdomain.com"; exit 1; }
DOMAIN=$(echo "$1" | sed -E 's#^https?://##; s#/$##')
cd "$(dirname "$0")/../bohio-website"
for f in *.html; do grep -q 'YOURDOMAIN\.com' "$f" && sed -i.bak "s#YOURDOMAIN\.com#$DOMAIN#g" "$f" && rm -f "$f.bak" && echo "updated $f"; done
echo "Done: links now point to https://$DOMAIN"
