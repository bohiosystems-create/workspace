# Bohio Systems website + Kinan demo — deploy guide

## What is in this package

| Folder | What it is | Needed? |
|---|---|---|
| `bohio-website/` | Your website, ready to upload. The **Kinan — AI Assistant Director of Marketing** demo is built into the **Demo portal** (`/demos`): sign in, then **present** (full screen) or **new tab**. | **Yes** — this is what goes on your domain |
| `tools/` | One script that puts your domain into the page links (`set-domain.ps1` for Windows, `set-domain.sh` for Mac/Linux). | Run once before uploading |
| `kinan-live-app/` | The full Kinan application (Next.js server) for live AI answers, ElevenLabs voice, Outlook, CRM and Oracle connections. | Optional — only for the live version |

The website is static (HTML, JavaScript, fonts). It runs on any web host. The Kinan demo inside it works fully in the browser with sample data and built-in answers — no server, no keys.

What changed in your site:
- `index.html` added (a copy of `Site Inverted.dc.html`), so your domain opens the home page.
- `Demos.dc.html`: the Kinan demo is listed permanently (it can't be removed by mistake). Uploading your own demos works as before.
- `demos/kinan/index.html`: the Kinan demo (one file, about 2.7 MB). Kept out of search engines.
- `Workflows.dc.html`: its canonical link pointed to `/compliance`; now `/workflows`.
- `bohio-solar.js`: a small fix for a console error (a shrinking orbit could pass a negative size to the canvas).
- Hosting files: `.htaccess` (Apache / cPanel), `_redirects` and `_headers` (Netlify / Cloudflare Pages), `vercel.json` (Vercel), `robots.txt`. They give you clean addresses: `/workflows`, `/compliance`, `/privacy`, `/demos`, and `/kinan` → the demo.

---

## Step 1 — Put your domain in the links (2 minutes)

The pages contain `YOURDOMAIN.com` in their share/SEO links. Replace it once:

**Windows:** open PowerShell in this folder and run
```
powershell -ExecutionPolicy Bypass -File tools\set-domain.ps1 yourdomain.com
```
**Mac / Linux:**
```
sh tools/set-domain.sh yourdomain.com
```
(Or open the `.html` files in a text editor and replace `YOURDOMAIN.com` with your domain.)

Optional: add `favicon.ico`, `apple-touch-icon.png` and `og.png` (1200×630 share image) to `bohio-website/` — the pages already point to them.

---

## Step 2 — Upload the website (pick the one your domain uses)

### A. cPanel / shared hosting (GoDaddy, Hostinger, Namecheap, Bluehost…)
1. Open **File Manager** → `public_html` (or the folder for your domain). In Settings, tick **Show hidden files** (so `.htaccess` is uploaded too).
2. Upload **the contents** of `bohio-website/` (not the folder itself). Easiest: zip the contents, upload the zip, then **Extract** it in `public_html`.
3. Turn on HTTPS: cPanel → **SSL/TLS Status** → **Run AutoSSL** (free). The `.htaccess` then sends everyone to `https://`.

### B. Netlify (free)
1. Go to **app.netlify.com/drop** and drag the `bohio-website` folder onto the page.
2. **Domain management → Add a domain** → enter your domain and follow the DNS instructions (usually an `A` record to Netlify's IP for the root and a `CNAME` for `www`). HTTPS is automatic.

### C. Cloudflare Pages (free)
1. Cloudflare dashboard → **Workers & Pages → Create → Pages → Upload assets** → upload the `bohio-website` folder.
2. **Custom domains → Set up a custom domain**. If your DNS is on Cloudflare it is configured for you.

### D. Vercel (free)
1. Vercel dashboard → **Add New → Project** → deploy the `bohio-website` folder (or, with Node installed: `cd bohio-website` then `npx vercel --prod`).
2. **Settings → Domains → Add** your domain and set the DNS records Vercel shows.

DNS changes can take from a few minutes up to a few hours.

---

## Step 3 — Check it

- `https://yourdomain.com` — the home page.
- `https://yourdomain.com/workflows`, `/compliance`, `/privacy` — the other pages.
- `https://yourdomain.com/demos` — sign in with your portal username and password → **Kinan — AI Assistant Director of Marketing** → **present**.
- In the demo: Director, Initiatives, Vendors, Reports → **Preview today's report** → **▶ Play** (the animated presentation), the **العربية** toggle, and **Ask** (the assistant).
- Change the report from **Ask**: e.g. "remove the invoices section from the report", "move risks to the top of the report", "only show Andalus Quarter in the report", "add a pie chart of spend by channel to the report", "add a note to the report: …", then "undo the last report change". The card in the chat has **Preview the report**.

---

## Important — protecting the demo

The Demo portal's sign-in runs in the browser: it hides the list, but the demo file itself (`/demos/kinan/`) can be opened by anyone who has the link. It is kept out of search engines (`robots.txt` and a no-index header). For real protection, pick one:

- **cPanel / Apache:** cPanel → **Directory Privacy** → choose `public_html/demos` → enable password. (Or follow the notes in `bohio-website/demos/.htaccess`.)
- **Cloudflare (any host, free up to 50 users):** Zero Trust → **Access → Applications → Self-hosted** → path `yourdomain.com/demos/*` → allow your team's emails (they get a one-time code).
- **Netlify:** Site settings → **Access control → Password protection** (paid plans).

The demo uses sample data only — no real client data is in these files.

---

## Updating the Kinan demo later

Replace `bohio-website/demos/kinan/index.html` with the new file (same name) and upload it. Nothing else changes.

---

## Optional — the live version (`kinan-live-app/`)

The website demo answers with built-in rules and the browser's voice. The live version adds AI answers (Claude, OpenAI, Gemini), ElevenLabs narration for **▶ Play**, scheduled daily report emails through Outlook, and the CRM (read-only, from Kinan's sales agent in Yardi) / Oracle / Meta connections. It needs a server (Node.js), so it runs on a subdomain such as `kinan.yourdomain.com`.

**Easiest: a small VPS with Docker** (e.g. Hetzner, DigitalOcean, AWS Lightsail — 2 GB RAM is enough)
1. Copy the `kinan-live-app` folder to the server.
2. `cp .env.example .env` and fill in what you use. At minimum one AI key (`ANTHROPIC_API_KEY`), plus `ELEVENLABS_API_KEY` for the voice. Leave the `*_MODE=mock` lines as they are until each real connection is ready.
3. Build and start:
   ```
   docker build -t kinan-director .
   docker run -d --name kinan --restart unless-stopped -p 3000:3000 --env-file .env -v kinan-data:/data kinan-director
   ```
4. Point `kinan.yourdomain.com` (DNS `A` record) to the server and put HTTPS in front with **Caddy** (`/etc/caddy/Caddyfile`):
   ```
   kinan.yourdomain.com {
     basic_auth {
       kinan PASTE_HASH_HERE
     }
     reverse_proxy localhost:3000
   }
   ```
   Create the hash with `caddy hash-password`. **Keep this password on** — the live app has no login of its own and can use paid AI and voice credits.
5. To present the live version from the portal, change the Kinan entry's `url` in `bohio-website/Demos.dc.html` (search for `demos/kinan/index.html`) to `https://kinan.yourdomain.com` and re-upload that file.

Platforms that build from the included `Dockerfile` (Railway, Render, Fly.io) also work: add the same environment variables and a persistent volume mounted at `/data`.

More detail on every setting: `kinan-live-app/README.md` and `kinan-live-app/docs/`.
