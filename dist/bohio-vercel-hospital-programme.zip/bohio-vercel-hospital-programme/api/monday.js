const MONDAY_API='https://api.monday.com/v2';
const ALLOWED_ACTIONS=new Set(['deliverable_verified','schedule_change']);

function reply(res,status,payload){res.status(status);res.setHeader('Content-Type','application/json; charset=utf-8');return res.send(JSON.stringify(payload));}
function text(value,max=600){return String(value||'').replace(/[<>]/g,'').trim().slice(0,max);}
async function graph(query,variables={}){
  const response=await fetch(MONDAY_API,{method:'POST',headers:{Authorization:process.env.MONDAY_API_TOKEN,'Content-Type':'application/json','API-Version':'2026-04'},body:JSON.stringify({query,variables})});
  const payload=await response.json();
  if(!response.ok||payload.errors?.length)throw new Error(payload.errors?.map(x=>x.message).join('; ')||`Monday API ${response.status}`);
  return payload.data;
}
async function findOrCreateItem(boardId,taskId,taskName){
  const data=await graph('query ($board: [ID!]!) { boards(ids: $board) { items_page(limit: 100) { items { id name } } } }',{board:[boardId]});
  const marker=`[${taskId}]`,items=data.boards?.[0]?.items_page?.items||[];
  const existing=items.find(item=>item.name.includes(marker));
  if(existing)return existing;
  const created=await graph('mutation ($board: ID!, $name: String!) { create_item(board_id: $board, item_name: $name) { id name } }',{board:boardId,name:`${marker} ${text(taskName,160)}`});
  return created.create_item;
}
module.exports=async function handler(req,res){
  if(req.method==='GET'){
    const configured=Boolean(process.env.MONDAY_API_TOKEN&&process.env.MONDAY_BOARD_ID);
    return reply(res,200,{configured,boardId:configured?process.env.MONDAY_BOARD_ID:'',boardUrl:configured?`https://monday.com/boards/${process.env.MONDAY_BOARD_ID}`:'',mode:'Verified deliverables and approved date changes only'});
  }
  if(req.method!=='POST')return reply(res,405,{error:'Method not allowed'});
  if(!process.env.MONDAY_API_TOKEN||!process.env.MONDAY_BOARD_ID)return reply(res,503,{error:'Monday is not configured. Add MONDAY_API_TOKEN and MONDAY_BOARD_ID in Vercel.'});
  const body=typeof req.body==='string'?JSON.parse(req.body||'{}'):(req.body||{}),action=text(body.action,40);
  if(!ALLOWED_ACTIONS.has(action))return reply(res,400,{error:'Only verified deliverables and approved schedule changes can sync.'});
  const taskId=text(body.taskId,40),taskName=text(body.taskName,180),detail=text(body.detail,900),reporter=text(body.reporterRole||'Planner / Project Manager',80);
  if(!taskId||!taskName||!detail)return reply(res,400,{error:'taskId, taskName and detail are required.'});
  try{
    const item=await findOrCreateItem(process.env.MONDAY_BOARD_ID,taskId,taskName),label=action==='deliverable_verified'?'Verified deliverable':'Approved schedule change',evidence=text(body.evidenceUrl,500);
    const updateBody=`<b>Bohio · ${label}</b><br>${detail}<br><br>Reported by: ${reporter}${evidence?`<br>Evidence: ${evidence}`:''}`;
    const result=await graph('mutation ($item: ID!, $body: String!) { create_update(item_id: $item, body: $body) { id created_at } }',{item:item.id,body:updateBody});
    return reply(res,200,{ok:true,itemId:item.id,itemName:item.name,updateId:result.create_update.id,boardUrl:`https://monday.com/boards/${process.env.MONDAY_BOARD_ID}/pulses/${item.id}`});
  }catch(error){return reply(res,502,{error:text(error.message,500)});}
};
