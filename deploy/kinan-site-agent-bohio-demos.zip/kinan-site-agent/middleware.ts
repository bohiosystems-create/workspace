import { NextRequest, NextResponse } from "next/server";

// Bohio demo gate — the same file in every demo app on *.bohiotech.com.
// Visitors sign in once at bohiotech.com/demo; that sign-in (cookie `bohio_demo`, signed with the
// shared DEMO_SESSION_SECRET) lists the apps the account may open. This app lets in only accounts
// whose list includes DEMO_APP_ID (or the admin). Everyone else is sent to the sign-in page.
//
// Settings (Vercel → Environment Variables):
//   DEMO_SESSION_SECRET  the same value as on the bohiotech.com project (link it as a shared variable)
//   DEMO_APP_ID          this app's id, as listed in bohiotech-site/api/_config.js (kinan-site-agent)
//   DEMO_PORTAL_URL      optional, default https://www.bohiotech.com/demo

// Endpoints machines call with their own key stay outside the gate: the WhatsApp webhook (Meta signature),
// CSV import and the purchasing-system hook (bearer secrets).
const OPEN = ["/api/whatsapp", "/api/import", "/api/integrations/procurement"];
const COOKIE = "bohio_demo";

function safeEqual(a: string, b: string) {
  let diff = a.length ^ b.length;
  for (let i = 0; i < Math.max(a.length, b.length); i++) diff |= (a.charCodeAt(i) || 0) ^ (b.charCodeAt(i) || 0);
  return diff === 0;
}

async function hmac(secret: string, data: string) {
  const enc = new TextEncoder();
  const key = await crypto.subtle.importKey("raw", enc.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const sig = await crypto.subtle.sign("HMAC", key, enc.encode(data));
  return [...new Uint8Array(sig)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

async function allowed(token: string, secret: string, appId: string) {
  if (!token || !secret || secret.length < 32 || !appId) return false;
  const parts = token.split(".");
  if (parts.length !== 2 || !/^[A-Za-z0-9_-]+$/.test(parts[0])) return false;
  if (!safeEqual(parts[1], await hmac(secret, parts[0]))) return false;
  try {
    const json = decodeURIComponent(escape(atob(parts[0].replace(/-/g, "+").replace(/_/g, "/"))));
    const c = JSON.parse(json);
    if (!c || typeof c.u !== "string" || !Number.isFinite(c.exp) || c.exp < Math.floor(Date.now() / 1000)) return false;
    return c.a === true || (Array.isArray(c.d) && c.d.includes(appId));
  } catch {
    return false;
  }
}

export async function middleware(req: NextRequest) {
  if (OPEN.includes(req.nextUrl.pathname)) return NextResponse.next();
  const ok = await allowed(req.cookies.get(COOKIE)?.value ?? "", process.env.DEMO_SESSION_SECRET ?? "", process.env.DEMO_APP_ID ?? "");
  if (ok) return NextResponse.next();

  const noStore = { "Cache-Control": "no-store", "X-Robots-Tag": "noindex, nofollow" };
  if (req.nextUrl.pathname.startsWith("/api/")) {
    return NextResponse.json({ error: "Sign in at bohiotech.com/demo" }, { status: 401, headers: noStore });
  }
  const portal = new URL(process.env.DEMO_PORTAL_URL || "https://www.bohiotech.com/demo");
  const back = new URL(req.nextUrl.pathname + req.nextUrl.search, `https://${req.headers.get("host") ?? req.nextUrl.host}`);
  portal.searchParams.set("next", back.toString());
  const res = NextResponse.redirect(portal, 302);
  for (const [k, v] of Object.entries(noStore)) res.headers.set(k, v);
  return res;
}

export const config = { matcher: ["/((?!_next/static|_next/image|favicon.ico|icon.svg|manifest.webmanifest).*)"] };
