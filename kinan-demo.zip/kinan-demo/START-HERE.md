# Kinan demo — AI Director of Marketing

Everything you need to demo the AI Director of Marketing to Kinan.

| File | What it is |
|---|---|
| `1-OPEN-ME-demo.html` | **The demo.** One file: double-click it to open in Chrome or Edge. No install, no account, no internet needed (only the fonts load online). |
| `2-demo-kit-capabilities-and-checklist.html` | Capabilities, integration status and the demo checklist with tick-boxes (ticks are saved in your browser). |
| `docs/demo-checklist.md` | The same checklist as text, with the question bank and the recovery tips. |
| `docs/capabilities.md` | What the director does, the integration status, and the data sources that would sharpen its recommendations. |
| `docs/kinan-integration.md` | How the director and Kinan's agent exchange data, and the questions to settle with Kinan. |
| `app-source/` | The full application, to run it live (below). |

## Option 1 — the demo file (recommended)

1. Double-click **`1-OPEN-ME-demo.html`**. Use Chrome or Edge, with the window at least 1366 px wide.
2. Type your name in **Approving as** on the Director page.
3. Follow `2-demo-kit-capabilities-and-checklist.html` (about 35 minutes).

Reloading the page resets the demo to its starting state. All data is sample data frozen on **8 June 2026**; nothing is sent anywhere. The assistant uses its built-in answers (no AI key needed).

## Option 2 — the live app (to show free-form AI chat or the APIs)

Needs **Node.js 18.17 or newer** (the LTS from https://nodejs.org) and internet access for the install.

```bash
cd app-source
npm install
npm run setup        # creates .env (everything in mock mode) and a fresh sample database
npm run dev          # then open http://localhost:3001
```

- The first page load creates the sample data; allow about 20 seconds.
- **Free-form AI chat (optional):** open `app-source/.env` and set `ANTHROPIC_API_KEY` and/or `OPENAI_API_KEY`, then restart `npm run dev`. With both keys set, if one provider fails the other answers. Without a key the assistant uses the same built-in answers as the demo file.
- **Reset before the demo:** stop the app, run `npm run setup`, then `npm run dev`.
- Port 3001 busy? Run `npx next dev -p 3002` and open http://localhost:3002.
- Windows: run the commands in PowerShell or Command Prompt; they are the same.

## Say this upfront

1. **Sample data, frozen on 8 June 2026.** Realistic but invented vendors, campaigns, leads and invoices.
2. **Integrations are simulated** (Kinan's agent, Yardi, Outlook, Oracle, Meta), and the screens say so. Nothing is sent to anyone.
3. **One manager, no team.** The director does the team's work; the manager only approves. Leads, follow-up and sales stay with Kinan's own agent.
